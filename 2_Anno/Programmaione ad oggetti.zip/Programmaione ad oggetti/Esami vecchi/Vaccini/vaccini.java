/**
*	Mission: gestisce la campagna regionale delle vaccinazioni e contiene i metodi obbligatori specificati nel testo
*/
public class CampagnaVaccinaleRegionale{
	
	private list<Persona> elencoCittadini;
	
	/** 
	*	CampagnaVaccinaleRegionale: ha una lista delle persone che vivono nella regione
	*	Persona: contiene le anagrafiche delle persone e la loro cartella clinica
	*			 CartellaClinica: contiene i dati sulle vaccinazioni di una persona e la lista delle vaccinazioni
	*	Patologia: contiene il nome della patologia, i vaccini che possono essere utilizzati e le regole della vaccinazione
	*	Vaccino: contiene il nome del vaccino, l'età minima di somministrazione, distanza minima e massima dei richiami, il dosaggio e la durata
	*	Vaccinazioni: contiene la data di vaccinazione e il tipo di vaccino
	*/
	
	public class Vaccino{
		private int etàMinima;
		private int distanzaMinimaSomministrazione;
		private int distanzaMassimaSomministrazione;
		private int dose;
		private int durata;
		
		public Vaccino() {
		this.etàMinima = etàMinima;
		this.distanzaMinimaSomministrazione = distanzaMinimaSomministrazione;
		this.distanzaMassimaSomministrazione =distanzaMassimaSomministrazione;
		this.dose = dose;
		this.durata = durata;
		}
		
		public void configuraEtàMinima(int età){
			if(età!=NULL){
			this.etàMinima = età;}
		}
		public void configuraDosaggio(int dosaggio){
			if(dosaggio!=NULL){
			this.dosaggio = dosaggio;}
		}
		public void configuraDurata(int durata){
			if(durata!=NULL){
			this.durata = durata;}
		}
	}
	
	/**
	*	Mission: estrae dall'elenco degli abitanti della regione le persone che risultano vaccinate
	*	@return un elenco di Persona che risultano vaccinate almeno una volta
	*	@throws NessunaCittadinoVaccinatoException se nessun abitante è vaccinato
	*/
	Stream<Persona> elencaPersoneVaccinate()throws NessunaCittadinoVaccinatoException{
		FiltroAstratto<Persona> filtroPersona = new filtroPersona();
		Stream<Persona> risultato = filtroPersona.filtra(elencoCittadini, new filtroVaccinazioni()!=NULL);
		 if(risultato == null){
					throw new NessunaCittadinoVaccinatoException();
		 }
	}
	
	/**
	*	Mission: Data una Persona e una patologia restituisce la sua copertura vaccinale e la data del richiamo vaccinale
	*	@param persona REQUIRED NOT NULL, rappresenta la persona di cui verificare la copertura vaccinale
	*	@param patologia REQUIRED NOT NULL, rappresenta la patologia di cui verificare la vaccinazione
	*	@return i dati relativi alla data del richiamo vaccinale e della durata del vaccino restante
	*	@throws PersonaNonVaccinataException se la persona non risulta vaccinata a tale patologia
	*/
	public String copertura(Persona persona, Patologia patologia) throws PersonaNonVaccinataException{
	if(persona.CartellaClinica.VerificaVaccinazione(patologia)==FALSE){
		throw new PersonaNonVaccinataException();
	}
	else{	
		return ("Il prossimo richiamo risulta:" persona.CartellaClinica.ProssimoRichiamo(patologia) +
				" e la copertura vaccinale risulta di:" persona.CartellaClinica.DurataVaccinazione(patologia);
		}
	}
	
	/**
	* 	Mission: Permette di configurare le regole sulla somministrazione di un determinato vaccino
	*			 se un parametro viene specificato come NULL significa che tale parametro non va modificato
	*	@param vaccino REQUIRED NOT NULL, rappresenta il vaccino da andare a configurare le regole di somministrazione
	*	@param etàMinima raprpesenta l'età minima di somministrazione del vaccino
	*	@param dosaggio rappresenta il dosaggio da somministrare in ml del vaccino 
	*	@param durata rappresenta quanto durerà la copertura vaccinale una volta effettuato il vaccino
	*/
	public void configuraRegla(Vaccino vaccino, int etàMinima, int dosaggio, int durata){
		vaccino.configuraEtà(etaMinima);
		vaccino.configuraDosaggio(dosaggio);
		vaccino.configuraDurata(durata);
	}
}

public class Main{
	public static void main(String[] args) {
		
		//Do per scontato che l'elenco dei cittadini abbia già al suo interno un numero finito di elementi
		//Do per scontato che siano già state create delle patologie
		//Do per scontato che siano già stati creati dei vaccini
		
		//Creo la campagna regionale vaccinale del FVG passandogli l'elenco di tutti i cittadini
		CampagnaVaccinaleRegionale FVG = new CampagnaVaccinaleRegionale(elencoCittadini);
		
		//Mi restituisce un elenco delle persone vaccinate in FVG cooi rispettivi dati
		vaccinatiInFriuli = FVG.elencaPersoneVaccinate();
		
		//Consente di verificare se il cittadino del FVG Davide Volpi risulta vaccinato per l'ebola e 
		//per quanto tempo ancora sarà coperto e l'eventuale data del richiamo
		FVG.copertura(DavideVolpi, Ebola);
		
		//In seguito a degli studi si è scoperto che il vaccino Pfizer per il covid19 può essere somministrato
		//a partire dai 15 anni e non più dai 18 quindi va modificata la regola di tale vaccino
		FVG.configuraRegola(Pfizer, 15, NULL, NULL);
	}
}