import java.util.Collection;
// Rappresenta la rete ferroviaria, ovvero l'insieme di tutti i possibili percorsi che ci interessano
public interface ReteFerroviaria {
    public  void AggiungiStazione(Stazione st);
    public  void AggiungiTratta(Tratta tr);


}
