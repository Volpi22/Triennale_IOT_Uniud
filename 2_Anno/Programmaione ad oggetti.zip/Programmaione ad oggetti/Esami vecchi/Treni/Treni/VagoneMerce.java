// rappresenta il vagone merce. si suppone che ogni vagone possa portare una sola merce, di cui ci interessa unicamente il tipo
public class VagoneMerce extends MaterialeRotabile{
    private Merce merce;


    @Override
    public int getPeso() {
        return this.peso+Merce.getPeso();
    }
}
