import java.util.Date;
import java.util.function.Predicate;
import java.util.stream.Stream;

// Mission: implementazione concreta del gestore azienda
public class GestoreAziendaImpl extends GestoreAzienda {
    private GestoreViaggi gestoreViaggi;

    public GestoreAziendaImpl(ReteFerroviaria rf){


    }

    /**
     * Aggiunge il materiale rotabile
     * @param materialeRotabile : il materiale rotabile (vagone o locomotiva da aggiungere) REQUIRED NOT NULL;
     *
     */
    @Override
    public void AggiungiMaterialeRotabile(MaterialeRotabile materialeRotabile) {

    }

    /**
     * @param viaggio
     * @param info    : REQUIRED NOT NULL, le informazione che permettono la modifica (ovvero i vagoni da aggiungere, togliere, e le locomotive)
     *
     */
    @Override
    public void modificaTreno(Treno treno, InformazioniModifica info) {

    }

    /**
     * @param pred Il predicatpo
     * @return stream di treni di nostro interesse
     *   Cerca qi treni che rispondono alle nostre richieste
     */
    @Override
    public Stream<Treno> cercaTreni(Predicate<Viaggio> pred) {
        gestioneViaggi.cercaViaggia(pred);
    }

    @Override
    public void creaViaggio(Date date, Stazione origine, Stazione destinazione, Merce acqua) {
        gestioneViaggi.aggiungiViaggio();
    }
}
