// Mission: è la classe astratta che prevede la definizione delle interfaccie necessarie alla gestione del progetto.
// vengono implementate le funzioni con interfaccia comune
// sa eseguire query ad alto livello delle richieste con chiamate a funzioni della sua implementazione.
public abstract class GestoreAzienda {

    /**
     * @param materialeRotabile : il materiale rotabile (vagone o locomotiva da aggiungere) REQUIRED NOT NULL;
     * @throws VagoneGiaPresenteException : Eccezione invocata nel caso questo sia già nella nostra flotta
     */
    public abstract void AggiungiMaterialeRotabile(MaterialeRotabile materialeRotabile) ;

    /**
     * @param inizio : REQUIRED NOT NULL,  la data da cui iniziare la ricerca
     * @param fine : REQUIRED NOT NULL, la data in cui termina la ricerca
     * @param stazione: REQUIRED NOT NULL, la stazione in cui deve passare il treno nell'intervallo
     * @return: Stream<Treno>, ovvero la lista dei treni che rispettano i parametri, può essere vuoto, ma non NULL
     */
    public Stream<Treno> elencoTreniOrdini(Date inizio, Date fine, Stazione stazione){
        return cercaTreni(
                viaggio->
                        viaggio.PassaPer(stazione) &&
                        viaggio.getData().after(inizio) &&
                        viaggio.getData().before(fine) );
    }


    /** Non possiamo sapere la composizione di un treno in generale, e neanche per che viaggio è assegnato dato che potrebbe essere usato per diversi,
     *  Quindi richiediamo che venga passato il treno e non il viaggio
     * @param treno : REQUIRED NOT NULL, Il viaggio che vogliamo modificare
     * @param info : REQUIRED NOT NULL, le informazione che permettono la modifica (ovvero i vagoni da aggiungere, togliere, e le locomotive)
     *
     */
    public abstract void modificaTreno(Treno treno,InformazioniModifica info) ;


    /**
     * Esegue la stessa cosa del metodo successivo, senza parametro.
     * @return
     */
    public Stream<MaterialeRotabile> statoMaterialeRotabile(){
        return statoMaterialeRotabile(t->true);
    }

    /** Ritorna il materiale rotabile (quindi i treni) che verranno usati secondo un certo parametro.
     * TODO: Sistemare e fare in modo che ritorni il treno
     * @param pred Filto di ricerca sul treno
     * @return: stream dei vari materiali rotabili
     */
    public Stream<MaterialeRotabile> statoMaterialeRotabile(Predicate<Treno> pred) {
        Stream<MaterialeRotabile> ris = Stream.empty();
        return cercaTreni(viaggio -> pred.test(viaggio.getTreno()));

    }

    /**
     * @param data REQUIRED NOT NULL: la data in cui si riferisce la ricerca
     * @return : Una mappa di associazione tra materiale rotabile e treno usato
     */
    public Map<MaterialeRotabile,Treno> utilizzoPrevisto(Date data){
        Map<MaterialeRotabile,Treno> ris=new HashMap<>();
        for (Treno t: cercaTreni(viaggio -> data.equals(viaggio.getData())).collect(Collectors.toList())){
            for (MaterialeRotabile mat:t.toStream().collect(Collectors.toList())) {
                ris.put(mat,t);
            }
        }
        return ris;
    }


    /**
     * Funzione che ricerca i treni in base al fatto che il viaggio che li riguarda rispetta o meno un certo predicato.
     * @param pred Il predicatpo
     * @return Stream di treni
     */

    protected abstract Stream<Treno> cercaTreni(Predicate<Viaggio> pred);

    /** Permette di aggiungere un viaggio ai nostri
     * @param date Data di effettuazione del viaggio
     * @param origine Stazione di origine
     * @param destinazione Stazione di destinazione
     * @param merce la merce che ci interessa
     *
     *              Tutti i parametri REQUIRED NOT NULL
     */
    public abstract void creaViaggio(Date date, Stazione origine, Stazione destinazione, Merce merce);
}
