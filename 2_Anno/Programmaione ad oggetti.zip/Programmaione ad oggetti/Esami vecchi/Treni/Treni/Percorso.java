import java.util.*;

// Rappresenta la successione delle stazioni per arrivare da una città a un'altra
public class Percorso {
    private List<Stazione> stazioniCoinvolte;

    public  boolean passaPer(Stazione stazione) {
        return this.stazioniCoinvolte.contains(stazione);
    }

}

