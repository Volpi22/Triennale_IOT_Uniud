// la classe che si occupa di gestire i viaggi, implementando la possibilità di aggiungere, rimuovere e modificare i viaggi.
// permette l'importazione dei viaggi delle altre compagnie,
public class GestoreViaggi {
    //TODO : creare la possibilità di importare i viaggi e crearne di nuovi.

}
