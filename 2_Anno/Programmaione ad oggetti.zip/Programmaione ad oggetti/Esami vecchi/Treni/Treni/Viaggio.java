import java.util.Date;

// Rappresenta il viaggio, ovvero il percorso che un treno deve effettuare su un percorso
// Questo comprende dunque il treno, la data, il cliente, e il precorso.
public class Viaggio {
    private Treno treno;
    private Percorso percorso;

    private Date dataViaggio;



    /** Ci dice se un percorso passa o meno per una stazione
     * @param stazione
     * @return
     */

    public boolean PassaPer(Stazione stazione) {
        return percorso.passaPer(stazione);

    }

    public Date getData() {
        return dataViaggio;
    }

    public void setData(Date dataViaggio) {
        this.dataViaggio = dataViaggio;
    }
}
