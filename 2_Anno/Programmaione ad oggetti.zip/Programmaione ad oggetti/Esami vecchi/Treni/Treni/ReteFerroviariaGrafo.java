import java.util.ArrayList;
import java.util.List;

// Gestisce la rete ferroviaria come un grafo
public class ReteFerroviariaGrafo implements ReteFerroviaria {

    private List<Stazione> nodi=new ArrayList<>();
    private List<Tratta> archi=new ArrayList<>();
    @Override
    public void AggiungiStazione(Stazione st) {
        nodi.add(st);
    }

    @Override
    public void AggiungiTratta(Tratta tr) {
        archi.add(tr);
    }
}
