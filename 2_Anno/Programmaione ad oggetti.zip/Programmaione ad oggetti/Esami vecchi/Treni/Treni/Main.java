import java.text.DateFormat;
import java.util.Date;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Stazione stPord=new Stazione("Pordenone");

        Tratta tratta=new Tratta(stPord, new Stazione("Conegliano"), new Stazione("Udine"));

        ReteFerroviaria rf=ReteFerroviariaFactory.creaRete();

        rf.AggiungiStazione(new Stazione("Pordenone"));
        rf.AggiungiStazione(new Stazione("Conegliano"));
        rf.AggiungiStazione(new Stazione("Udine"));


        GestoreAzienda gestoreAzienda;

        gestoreAzienda=GestoreAziendaFactory.creaGestore(rf);
        gestoreAzienda.creaViaggio(new Date("18-08-2022"),stPord,new Stazione("Udine"),new Merce("Acqua",5) );

        Stream<Viaggio> viaggi=gestoreAzienda.elencoTreniOrdini(new Date("15-08-2022"),new Date("15-08-2022"),stPord);


        Treno treno=gestoreAzienda.elencoTreniOrdini(new Date("15-08-2022"),new Date("15-08-2022"),stPord).iterator().next();
        gestoreAzienda.modificaTreno(treno,
                (new InformazioniModifica.Builder())
                        .aggiungiVagoneMerce(new VagoneMerce(new VagoneMerce(...)))
                        .rimuoviVagoneMerce(new VagoneMerce(new VagoneMerce(...)))


                );
        Stream<MaterialeRotabile> mat=gestoreAzienda.statoMaterialeRotabile();
        gestoreAzienda.utilizzoPrevisto(new Date("23-01.2022"));

        System.out.println("Hello world!");
    }
}