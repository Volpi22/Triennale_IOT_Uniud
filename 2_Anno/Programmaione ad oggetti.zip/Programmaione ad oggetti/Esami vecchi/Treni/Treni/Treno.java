import java.util.Collection;
import java.util.Iterator;
import java.util.stream.Stream;

// Rappresenta la classe astratta treno come insieme di materiale rotabile. Questo viene distinto in locomotive e vagoni.
public abstract class Treno implements  Stream{
    Collection<Locomotiva> locomotive;
    Collection<VagoneMerce> vagoni;

    public Stream<MaterialeRotabile> toStream(){
        return Stream.concat(locomotive.stream(),vagoni.stream());
    }


}
