// il materiale rotabile, ovvero locomotive e vagoni merce.
// Sa solo il peso di questo, e in caso altre caratteristiche richieste
public abstract class MaterialeRotabile {
    protected int peso;

    public abstract   int getPeso();

    private String nome;
    private String modello;
}
