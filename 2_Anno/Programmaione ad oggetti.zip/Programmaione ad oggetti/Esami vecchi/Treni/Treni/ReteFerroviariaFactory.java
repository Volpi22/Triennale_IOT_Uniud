// Factory per la rete ferroviaria
public class ReteFerroviariaFactory {

    public static ReteFerroviaria creaRete() {
        return new ReteFerroviariaGrafo();
    }
}
