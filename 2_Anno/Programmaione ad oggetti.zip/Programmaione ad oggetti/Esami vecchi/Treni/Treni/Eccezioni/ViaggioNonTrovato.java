// eccezioni in cui non sia stato trovato il viaggio
class ViaggoNonTrovatoExceptrion extends Exception{}
