// gestisce l'eccezione in cui il treno a cui ci riferiamo non esista
public class TrenoNonTrovato extends Exception {
}
