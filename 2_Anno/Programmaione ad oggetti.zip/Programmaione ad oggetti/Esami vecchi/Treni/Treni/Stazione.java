// Mission: rappresenta una stazione
public class Stazione {
    String nome;

    public Stazione(String  nome) {
        this.nome=nome;
    }


    public boolean equals(Stazione stazione) {
        return stazione.nome.equals(this.nome);

    }
}
