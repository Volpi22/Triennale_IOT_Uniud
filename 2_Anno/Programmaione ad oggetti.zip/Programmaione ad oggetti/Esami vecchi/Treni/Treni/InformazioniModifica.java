import java.util.List;

// Mission che ci permette di passare le informazioni riguardo alle modifiche che vogliamo apportare al treno.
public class InformazioniModifica {

    List<MaterialeRotabile> materialeAggiunto;
    List<MaterialeRotabile> materialeTolto;
    public  InformazioniModifica(Builder build){
        this.materialeAggiunto=build.materialeAggiunto;
        this.materialeTolto=build.materialeTolto;

    }


    public class Builder {

        protected List<MaterialeRotabile> materialeAggiunto;
        protected List<MaterialeRotabile> materialeTolto;
        public Builder(){};

        public Builder aggiungiVagoneMerce(VagoneMerce vagoneMerce){
            materialeAggiunto.add((vagoneMerce));
            return  this;
        }
        public Builder togliVagone(VagoneMerce vagoneMerce){
            materialeTolto.add(vagoneMerce);
            return this;
        }
        public InformazioniModifica build(){
            return new InformazioniModifica(this);
        }
    }
}
