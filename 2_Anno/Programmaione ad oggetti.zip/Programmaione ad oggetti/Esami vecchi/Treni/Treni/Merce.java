import java.util.EnumMap;

// Definisce la merce. Questa può essere di vari tipi. Il calcolo del peso è lo stesso


public class Merce {
    private String descrizione;
    private  int peso;
    private Merce.Tipo tipo;

    public Merce(Tipo tipo, String descrizione, int peso) {
    }

    public int getPeso(){
        return peso;
    }

    public enum Tipo {
        MERCESFUSA,
        FLUIDO,
        CONTAINER,
    }
}
