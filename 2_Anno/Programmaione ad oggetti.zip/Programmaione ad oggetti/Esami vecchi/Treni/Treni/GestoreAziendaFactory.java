// Factory per la creazione dell'azienda data la rete ferroviaria
public class GestoreAziendaFactory {
    public static GestoreAzienda creaGestore(ReteFerroviaria rf) {
        return new GestoreAziendaImpl(rf);
    }
}
