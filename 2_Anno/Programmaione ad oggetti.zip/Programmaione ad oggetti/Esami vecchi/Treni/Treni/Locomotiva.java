// Rappresenta la locomotiva. Di questa, oltre a nome e modello, possiamo anche sapere la potenza, ovvero quanto peso può portare
public class Locomotiva extends MaterialeRotabile {

    private int pesoPortato;


    @Override
    public int getPeso() {
        return pesoPortato;
    }
}
