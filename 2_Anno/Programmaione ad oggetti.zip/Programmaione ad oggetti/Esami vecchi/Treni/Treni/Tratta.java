import java.util.Iterator;

// Rappresenta una delle tratte, ovvero il collegamento da una città a un altra. Si suppongono le tratte unidirezionali
public class Tratta  {
    final Stazione origine;
    final Stazione destinazione;

    public  Tratta(Stazione origine,Stazione destinazione){
        this.origine=origine;
        this.destinazione=destinazione;
    }



}
