public class AziendaTrasporti {

	//Dentro stazione ci sarà una list<Treno> listaTreni che rappresenta la lista dei treni in quella stazione

	/**
	 * Ricerca quali treni e che tipo di materiale possono trasportare in una certa stazione un un determinato momento
	 * @param Stazione rappresenta la stazione dove verificare i treni
	 * @param data rappresenta la data in cui vogliamo vedere per cosa sarà usato il treno
	 * @return l'elenco dei treni che saranno presenti in quella stazione stazione in una determinata data
	 * @throws NessunTrenoInStazioneException se in stazione in quella data non saranno presenti treni
	 */
	Stream<Treno> elencoTreniOrdini(Stazione stazione, Date data)
				  throws NessunTrenoInStazioneException{
		FiltroAstratto<Treno> filtroTreno = new filtroTreno();
		Stream<Treno> risultato = filtroTreno(listaTreni, 
														  new UnaDelleDueCaratteristiche<>(
														      new FiltroPartenza(stazione, data),
															  new FiltroArrivo(stazione, data)));
		 if(risultato == null){
					throw new NessunaTrenoInStazioneException();
		 }
	}
	
	//Dentro stazione HashMap <Merce tipoMerce, int quantità> listaMerceStazione
	//Dentro treno    HashMap <Merce tipoMerce, int vagoni> listaMerceTreno

	/**
	 * Dato un treno e la merce con la rispettiva quantità, aggiorna la composizione del treno se fattibile
	 * @param treno rappresenta il treno in esame
	 * @param tipoMerce rappresenta che tipo di merce il treno dovrà trasportare
	 * @param quantità rappresenta la quantità di merce da inserire sul treno
	 * @throws MerceNonSufficienteException se nella stazione di partenza del treno non c'è abbastanza merce per aggiornare la composizione del treno
	 */
	public void modificaTreno(Treno treno, Merce tipoMerce, int quantità)
				throws MerceNonSufficienteException{
		if(treno.stazione.verificaDisponibilità(tipoMerce,quantità)){
			int vagoni = treno.calcolaVagoni(tipoMerce,quantità);
			treno.aggiornaMerce(tipoMerce, vagoni);
			treno.stazione.aggiornaMerceLibera(tipoMerce, quantità);
		}
		else{
			throw new MerceNonSufficienteException();
		}
	}
	
	/**
	 * Data una stazione in un determinato momento, si vuole sapere che materiale sarà presente in quella stazione
	 * @param stazione rappresenta la stazione dove andare a verificare che materiali saranno presenti
	 * @param data rappresenta la data in cui vogliamo vedere lo stato del materiale
	 * @return l'hasmap di ogni merce presente nella stazione in quel momento con la rispettiva quantità
	 */
	private HashMap statoMaterialeRotabile(Stazione stazione, Date data, int ora){
		FiltroAstratto<Treno> filtroTreno = new filtroTreno();
		Stream<Treno> listaTreniProiettata = filtroTreno(listaTreni, 
														  new UnaDelleDueCaratteristiche<>(
														      new FiltroPartenza(stazione, data, ora),
															  new FiltroArrivo(stazione, data, ora)));
		stazione.aggiungiMerceLibera(listaTreniProiettata);
		return stazione.listMerceStazione;
	}
	
	/**
	 * Dato un treno e una specifica data, restituisce che materiale trasporterà in quella data
	 * @param treno rappresenta il treno in esame
	 * @param data rappresenta la data in cui vogliamo vedere per cosa sarà usato il treno
	 * @return l'hasmap di ogni merce presente sul treno con la rispettiva quantità
	 * @throws TrenoNonOperativoException se il treno in esame in quella data non risulta programmato per una partenza
	 */
	public HashMap utilizzoPrevisto(Treno treno, Date data)
				   throws TrenoNonOperativoException{
		if(Registro.verificaOperatività(treno, data)==FALSE){
			throw new TrenoNonOperativoException();
		}
		else{
			return treno.listaMerceTreno;
		}
	}
}