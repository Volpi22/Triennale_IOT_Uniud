/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 
 public class NessunaTrenoInCorsaException extends Exception{}