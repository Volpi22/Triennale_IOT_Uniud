/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 
 /**
 * Assunzioni per il codice:
 * Tutti i treni partono sempre ad orari interi, come per esempio 1 2 3 4 ... 24 
 * Si assume che lo stato del materiale valga per tutto il materiale in stazione
 * Nella funzione maerialeInStazione si considerano solo treni che hanno finito la loro percorrenza
 * come anche nelle funzioni arrivato e partito, si intende solo luogo iniziale e finale
 * Diamo per scontato che le Stazioni siano già state create
 */
 
 public class Main {
	public static void main(String[] args) {
		//Creiamo l'azienda Frecce
		List<Treno> listaTreni = new vector<>;
		Frecce AziendaFrecce = new Frecce(listaTreni);
		
		//Creaiamo la lista di motrici, carrozze passeggeri, carrozze letto e carrozze ristorante
		list<int> listaCarrozze = new vector<>();
		listaCarrozze.add("1");
		listaCarrozze.add("4");
		listaCarrozze.add("4");
		listaCarrozze.add("2");
		
		//Creiamo due treni uguali contenenti le carrozze prima indicate
		Treno treno1 = AziendaFrecce.creaTreno("DMTM20",listaCarrozze, 200);
		AziendaFrecce.aggiungiTreno(treno1);
		Treno treno2 = AziendaFrecce.creaTreno("DMTM21",listaCarrozze, 200);
		AziendaFrecce.aggiungiTreno(treno2);
		
		//Creiamo una tratta per i due treni e la lista delle fermate intermedie
		list<Stazione> intermedi = new vector<>();
		intermedi.add(Padova);
		intermedi.add(Ferrara);
		TrattaFactory tratta1 = new TrattaFactory.TrattaBuilder(Udine, Bologna, intermedi);
		
		//Associamo i due percorsi ai due treni se possibile
		AziendaFrecce.associaPercorso(treno1, tratta1, 11/09/01, 10);
		AziendaFrecce.associaPercorso(treno2, tratta1, 11/09/01, 11);
		
		//Sono le 10 del 11/09/01 e il treno1 deve partire
		AziendaFrecce.partito(treno1, Udine);
		
		//Sono le 11 del 11/09/01 e il treno2 deve partire
		AziendaFrecce.partito(treno2, Udine);
		
		//Sono le 13 del 11/09/01 e il treno1 è arrivato
		AziendaFrecce.arrivato(treno1, Bologna);
		
		//Il treno1 durante il viaggio ha subito dei danni e quindi le carrozze letto saranno in manutenzione
		AziendaFrecce.inManutenzione(CARROZZE_LETTO, Bologna);
		
		//Dopo mezz'ora di manutenzione sono di nuovo disponibili le carrozze letto a Bologna
		AziendaFrecce.riabilita(CARROZZE_LETTO, Bologna);
		
		//Vogliamo vedere che treni ci sono in corsa attualmente, il treno2 sarà ancora in viaggio
		list<Treni> listaTreniInCorsa = AziendaFrecce.treniInCorsa();
				
		//Sono le 14 del 11/09/01 e il treno2 è arrivato
		AziendaFrecce.arrivato(treno2, Bologna);
		
		//Vogliamo vedere ora che materialiRotabili sono disponibili a Bologna
		HashMap materiale = AziendaFrecce.materialeInStazione(Bologna, 11/09/01, 15);
	}
 }