/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 public class Stazione {
	
	private HashMap<MaterialeRotabile materiale, int quantitàMateriale> materialePresente; 
	private HashMap<MaterialeRotabile materiale ,StatoTreno stato> statoMateriale; 
	
	private list<Treno> listaTreni;

	/**
	*	Aggiunge un treno alla lista dei treni presenti nella stazione
	*/
	public void aggiungiTreno(Treno treno){}
	
	/**
	*	Rimuove un treno dalla lista dei treni presenti nella stazione
	*/
	public void rimuoviTreno(Treno treno){}
	
	/**
	*	Aggiorna il materiale presente nella stazione col materiale presente su un treno
	*/
	public void aggiungiMateriale(Treno treno){}
	
	/**
	*	Aggiorna il materiale presente nella stazione col materiale presente su un treno
	*/
	public void aggiungiMateriale(list<Treno> listaTreni){}
	
	/**
	*	Aggiorna il materiale presente nella stazione rimuovendo il materiale presente su un treno
	*/
	public void rimuoviMateriale(Treno treno){}
	
	/**
	*	Dato un treno e una stazione vede se è possibile assegnarlo a quella stazione
	*/
	public bool disponibilitàMateriale(Treno treno)
	
 }