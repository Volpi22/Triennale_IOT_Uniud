/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 public enum MaterialeRotabile {
	MOTRICI(1), CARROZZE_PASSEGGERI(2), CARROZZE_LETTO(3),CARROZZE_RISTORANTE(4);
 }
 
/**

abstract class MaterialeRotabile{
	
	protected int numero;
	
	public abstract int getNumero(){}
}
 
 public class Motrice extends MaterialeRotabile{
	 
	private int numeroMotrici;
	
	@override
	public int getNumero(){}
 }
 
 public class Carrozza extends MaterialeRotabile{
	 
	public TipoVagone tipo;
	public intNumeroCarrozze;
	
	@override
	public int getNumero(){}
	 
	public enum TipoVagone {
	PASSEGGERI(1), LETTO(2),RISTORANTE(3);
	}
 }
 
*/