/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21  
 */
  public class QuestoStato implements CaratteristicaAstratta<Treno>{
	 private StatoTreno stato;
	 
	 public QuestoStato(StatoTreno stato){
		 this.stato = stato;
	 }
	 
	 //Restituisce se un vagone è in un certo stato
	 @Override
	 public boolean èSoddisfatta(Treno treno){
		return treno.StatoTreno() == stato;
	 }
 }