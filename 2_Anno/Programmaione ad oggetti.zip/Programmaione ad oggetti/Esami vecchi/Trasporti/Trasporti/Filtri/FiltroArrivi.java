/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21  
 */
   public class FiltroArrivi implements CaratteristicaAstratta<Treno>{
	 private Stazione stazione;
	 private Date dataArrivo;
	 private int oraArrivo
	 
	 public QuestoStato(Stazione stazione, Date dataPartenza, int oraPartenza){
		 this.stazione = stazione;
		 this.dataArrivo = dataArrivo;
		 this.oraArrivo= oraArrivo;
	 }
	 
	 //Restituisce se la stazione è quella cercata
	 @Override
	 public boolean èSoddisfatta(Treno treno){
		return ((treno.tratta.luogoPartenza() == stazione) 
			     && (treno.dataArrivo() <= data)
				 && (treno.orarioArrivo() < ora));
	 }
 }