/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21  
 */
  public class UnaDelleDueCaratteristiche<T> implements CaratteristicaAstratta<T>{
	 
	 public UnaDelleDueCaratteristiche(CaratteristicaAstratta<T> prima, CaratteristicaAstratta<T> seconda) {
        this.prima = prima;
        this.seconda = seconda;
	/**
     * Restituisce true se ha una delle due caratteristiche
     */
    @Override
    public boolean èSoddisfattaDa(T t) {
        return prima.èSoddisfattaDa(t) || seconda.èSoddisfattaDa(t);
    }
 }