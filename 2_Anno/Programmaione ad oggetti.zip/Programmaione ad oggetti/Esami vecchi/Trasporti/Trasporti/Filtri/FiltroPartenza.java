/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21  
 */
   public class FiltroPartenza implements CaratteristicaAstratta<Treno>{
	 private Stazione stazione;
	 private Date dataPartenza;
	 private int oraPartenza
	 
	 public QuestoStato(Stazione stazione, Date dataPartenza, int oraPartenza){
		 this.stazione = stazione;
		 this.dataPartenza = dataPartenza;
		 this.oraPartenza = oraPartenza;
	 }
	 
	 //Restituisce se la stazione è quella cercata
	 @Override
	 public boolean èSoddisfatta(Treno treno){
		return ((treno.tratta.luogoPartenza() == stazione) 
			     && (treno.dataPartenza() >= data)
				 && (treno.orarioPartenza() > ora));
	 }
 }