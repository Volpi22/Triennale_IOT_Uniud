/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 
 /**
 * Mission: Tratta tiene conto della stazione di partenza, di arrivo e delle stazioni intermedie
 */
 public class Tratta {
	
	private Stazione luogoPartenza;
	private Stazione luogoArrivo;
	private list<Stazione> intermedi;
	
	public Tratta(Stazione luogoPartenza, Stazione luogoArrivo, list<Stazione> intermedi){
		this.luogoPartenza = luogoPartenza;
		this.luogoArrivo = luogoArrivo;
		this.intermedi = intermedi;
	}
 }