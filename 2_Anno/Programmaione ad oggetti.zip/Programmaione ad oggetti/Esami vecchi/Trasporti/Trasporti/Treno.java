/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 public class Treno {
	 
	private String codiceMotrice;
	private int numeroMotrici=1;
	private int numeroCarrozzeLetto;
	private int numeroCarrozzePasseggeri;
	private int numeroCarrozzeRistorante;
	private int capacitàMassima;
	
	private Tratta tratta;
	
	private StatoTreno stato;
	
	private Date dataPartenza;
	private Date dataArrivo;
	private int orarioPartenza;
	private int orarioArrivo;
	
	/**
	*  Data una motrice la assegna al treno
	*  @param codiceMotrice il codice della motrice da assegnare
	*/
	private assegnaMotrice(String codiceMotrice){
		this.codiceMotrice=codiceMotrice;
	}
	
	/**
	*  Data una lista di vagoni, verifica se è possibile creare un treno con tali caratteristiche
	*  @param listaCarrozze il numero di ogni tipo di carrozze da inserire
	*  						in ordine saranno: motrici, carrozze passeggeri, carrozze letto, carrozze ristorante
	*/
	public bool verificaFattibilità(list<int> listaCarrozze){}
	
	/**
	*  Data una lista di carrozze le assegna al treno e modifica di conseguenza la sua capacità
	*  @param listaCarrozze è una lista che contiene il numero delle carrozze con cui comporre il treno
	*/
	private assegnaCarrozze(List<int> listaCarrozze){}
	
	/**
	*  Data una capacità minima vede se il treno la supporta
	*  @param capacità rappresenta la capacità di cui verificare se il treno è dotatose il treno può supportare tale capacità
	*  @return TRUE se il treno la supporta, FALSE se va in overflow
	*/
	private bool verificaCapacità(int capacità){
		return this.capacità>=capacità;
	}
	
	/**
	*  Data una tratta, assegna al treno quella tratta se è possibile
	*  @param tratta rappresenra la tratta che il treno deve percorrere
	*/
	private void assegnaTratta(Tratta tratta) throw TrattaNonDisponibileException{}
	
	/**
	*  Data una data di partenza la associa al treno
	*  @param dataPArtenza rappresenta la data di partenza del treno
	*/
	private void associaDataPartenza(Data dataPartenza){
		this.dataPartenza = dataPartenza;
	}
	
	/**
	*  Dato un orario lo associa all'orario di partenza del treno
	*  @param oraPartenza rappresenta l'orario di partenza del treno
	*/
	private void associaOraPartenza(Int oraPartenza){
		this.oraPartenza = oraPartenza;
	}
	
	/**
	*  Dato un treno modifica il suo stato
	*  @param stato rappresenta l'lo stato del treno da voler inserire
	*  @throws StatoInvalidoException se non è ammissibile il cambio di stato
	*/
	private void modificaStatoTreno(StatoTreno stato)
				 throw StatoInvalidoException{
		if(transizioneAmmissibile(this.statoTreno, stato))
			this.statoTreno=stato;
		else{
			throw new StatoInvalidoException;
		}
	}
 }