/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21  
 */
 public class enum StatoTreno {
	 IN_CORSA(1), IN_STAZIONE(2), IN_OFFICINA(3);
	 
	private int stato;
	private StatoTreno(int stato){
		this.stato = stato;
	}
	
	/**
     * Verifica se una transazione t: stato1 -> stato2 è ammissibile
     * (ad esempio una transazione da IN_CORSA a IN_OFFICINA non è ammissbile)
     * @param statoTreno1 lo stato antecedente alla transizione
     * @param statoTreno2 lo stato successivo alla transizione
     * @return true se la transizione è ammissibile
     */
	public static boolean transizioneAmmissibile(StatoTreno statoTreno1, StatoTreno statoTreno2){}
 }