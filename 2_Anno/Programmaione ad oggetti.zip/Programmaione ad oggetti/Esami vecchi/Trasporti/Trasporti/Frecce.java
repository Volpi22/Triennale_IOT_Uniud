 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 01/07/21 
 */
 public class Azienda {
	 
	private list<Treno> listaTreni; 
	
	/**
	* Aggiunge un treno alla lista dei treni 
	*/
	private void aggiungiTreno(Treno treno){}
	 
	/**
	*  Data una motrice, una serie di carrozze e una capacità minima, costruisce un treno
	*  @param codiceMotrice il codice della motrice da assegnare
	*  @param listaCarrozze è una lista che contiene il numero delle carrozze con cui comporre il treno
	*  @param capacità capacità minima che il treno deve avere
	*  @return il treno con le specifiche inserite
	*  @throws OverflowDiCapacitàException se la capacità rischiesta non è supportata
	*/
	public Treno creaTreno(String codiceMotrice, List<int> listaCarrozze, int capacità)
		   throws OverflowDiCapacitàException{
		if((Treno.verificaCapacità(capacità)==FALSE)&&(treno.verificaFattibilità(listaCarrozze))){
			throw new OverflowDiCapacitàException();}
		else{
			treno.assegnaMotrice(codiceMotrice);
			treno.assegnaCarrozze(List<Integer> listaCarrozze);
		}
	}
	
	/**
	*  Dato un treno, una tratta e un orario e una data di partenza li associa 
	*  @param treno rappresenta un treno 
	*  @param tratta rappresenta una tratta da seguire
	*  @param dataPartenza rappresenta il giorno in cui il treno partirà
	*  @param oraPartenza rappresenta l'orario di partenza del treno
	*/
	public void associaPercorso(Treno treno, Tratta tratta, Data dataPartenza, int oraPartenza)
				throws MaterialeInsufficienteException{
		if(tratta.luogoPartenza.disponibilitàMateriale(treno)){
			treno.assegnaTratta(tratta);
			treno.associaDataPartenza(dataPartenza);
			treno.associaOraPartenza(oraPartenza);
		}
		else{
			throw new MaterialeInsufficienteException();
		}
	}
	
	/**
	*  Dato un treno e una stazione aggiorna il suo stato e la sua posizione
	*  @param treno rappresenta un treno 
	*  @param stazione rappresenta la stazione da cui sta partendo
	*/
	public void partito(Treno treno, Stazione stazione){
		treno.modificaStatoTreno(IN_CORSA);
		stazione.rimuoviTreno(treno);
		stazione.rimuoviMateriale(treno);
	}
	
	/**
	*  Dato un treno e una stazione aggiorna il suo stato e la sua posizione
	*  @param treno rappresenta un treno 
	*  @param stazione rappresenta la stazione in cui sta arrivando
	*/
	public void arrivato(Treno treno, Stazione stazione){
		treno.modificaStatoTreno(IN_STAZIONE);
		stazione.aggiungiTreno(treno);
		stazione.aggiungiMateriale(treno);
	}
	
	/**
	*  Data una stazione e un materiale aggiorna lo stato di quel materiale in quella stazione
	*  @param materiale rappresenta il materiale a cui modificare lo stato
	*  @param stazione rappresenta la stazione dove modificare lo stato del materiale
	*/
	public void inManutenzione(MaterialeRotabile materiale, Stazione stazione){
		stazione.statoMateriale.put(materiale,IN_OFFICINA);
	}
	
	/**
	*  Data una stazione e un materiale aggiorna lo stato di quel materiale in quella stazione
	*  @param materiale rappresenta il materiale a cui modificare lo stato
	*  @param stazione rappresenta la stazione dove modificare lo stato del materiale
	*/
	public void riabilita(MaterialeRotabile materiale, Stazione stazione){
		stazione.statoMateriale.put(materiale,IN_STAZIONE);
	}
	
	/**
	*  Data una lista di treni restituisce quali treni hanno lo stato IN_CORSA, in caso non ci siano solleva un'eccezione
	*  @return restituisce la lista dei treni in corsa
	*  @throws NessunTrenoInCorsaException
	*/
	Stream<Treno> TreniInCorsa() throws NessunTrenoInCorsaException{
		FiltroAstratto<Treno> filtroTreno = new filtroTreno();
		Stream<Treno> risultato = filtroTreno.filtra(listaTreni, new QuestoStato(IN_CORSA));
		 if(risultato == null){
					throw new NessunaTrenoInCorsaException();
		 }
	}
	
	/**
	*  Data una stazione e una data e un'ora, estrae il materiale che sarà presente in quel luogo a quel determinato momento
	*  @param stazione rappresenta la stazione dove verificare il materiale
	*  @param data rappresenta la data da verificare 
	*  @param ora rappresenta l'ora da verificare 
	*  @return restituisce l'hashmap dei materiali presenti nella stazione
	*/
	private HashMap MaterialeInStazione(Stazione stazione, Date data, int ora){
		FiltroAstratto<Treno> filtroTreno = new filtroTreno();
		Stream<Treno> listaTreniProiettata = filtroTreno(listaTreni, 
														  new UnaDelleDueCaratteristiche<>(
														      new FiltroPartenza(stazione, data, ora),
															  new FiltroArrivo(stazione, data, ora)));
		stazione.aggiungiMateriale(listaTreniProiettata);
		return stazione.materialePresente;
	}
	
 }