public class TrattaFactory{
	private Stazione luogoPartenza;
	private Stazione luogoArrivo;
	private list<Stazione> intermedi;
	
	public Tratta(TrattaBilder trattaBuilder){
		this.luogoPartenza = richiestaBuilder.luogoPartenza;
		this.luogoArrivo = richiestaBuilder.luogoArrivo;
		this.intermedi = richiestaBuilder.intermedi;
	}
 }
 
 static class TrattaBuilder{
	private Stazione luogoPartenza;
	private Stazione luogoArrivo;
	private list<String> intermedi;
	
	public TrattaBuilder(Stazione luogoPartenza, Stazione luogoArrivo, list<Stazione> intermedi){
		this.luogoPartenza = luogoPartenza;
		this.luogoArrivo = luogoArrivo;
		this.intermedi = intermedi;
	}
	public Tratta build(){
		return new Tratta(this);
	}
 }