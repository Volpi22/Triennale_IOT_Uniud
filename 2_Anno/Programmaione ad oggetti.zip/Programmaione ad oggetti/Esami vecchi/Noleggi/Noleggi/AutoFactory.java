public class AutoFactory{
	
	private String targa;
	private int annoImmatricolazione;
	private Marca marca;
	private Modello modello;
	private Condizione condizione;
	private Stato stato;
	private int chilometraggio;
	
		public Auto(AutoBuilder autoBuilder){
		this.targa = autoBuilder.targa;
		this.annoImmatricolazione =	autoBuilder.annoImmatricolazione;
		this.marca = autoBuilder.marca;
		this.modello = autoBuilder.modello;
		this.condizione = autoBuilder.condizione;
		this.stato = autoBuilder.stato;
		this.chilometraggio = autoBuilder.chilometraggio;
	}
	
 }
 
 static class AutoBuilder{
	 
	private String targa;
	private int annoImmatricolazione;
	private Marca marca;
	private Modello modello;
	private Condizione condizione;
	private Stato stato;
	private int chilometraggio;
	
		public Auto(String targa, int annoImmatricolazione, 
					Marca marca, Modello modello, Condizione condizione, Stato stato, int chilometraggio){
			this.targa = targa;
			this.annoImmatricolazione =	annoImmatricolazione;
			this.marca = marca;
			this.modello = modello;
			this.condizione = condizione;
			this.stato = stato;
			this.chilometraggio = chilometraggio;
		}
		
		public Auto build(){
		return new Auto(this);
		}
 }