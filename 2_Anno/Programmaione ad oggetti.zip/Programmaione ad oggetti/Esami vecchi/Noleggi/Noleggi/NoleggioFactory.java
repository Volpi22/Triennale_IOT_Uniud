public class NoleggioFactory{
		
	private Auto auto;
	private Stato statoNoleggio = NOLEGGIATO;
	
	private String durata;
	private Date dataInizioNoleggio;
	private Date dataFineNoleggio;
	
		public Noleggi(NoleggioBuilder noleggioBuilder){
		this.auto = noleggioBuilder.auto;
		this.durata = noleggioBuilder.durata;
		
		this.dataInizioNoleggio = noleggioBuilder.dataInizioNoleggio;
		this.dataFineNoleggio = noleggioBuilder.dataFineNoleggio;
		}
}	
static class NoleggioBuilder{
	
	private Auto auto;
	private Stato statoNoleggio = NOLEGGIATO;
	
	private String durata;
	private Date dataInizioNoleggio;
	private Date dataFineNoleggio;
	
		public NoleggioBuilder(Auto auto, String durata, Date dataInizioNoleggio, Date dataFineNoleggio){
		this.auto = auto;
		this.durata = durata;
		
		this.dataInizioNoleggio = dataInizioNoleggio;
		}
		
		public Noleggio build(){
		return new Noleggio(this);
		}
	
 }