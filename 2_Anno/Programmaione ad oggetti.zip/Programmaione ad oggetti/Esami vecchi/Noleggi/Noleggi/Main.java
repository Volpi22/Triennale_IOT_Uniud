/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
/**
 * Assunzioni per lo sviluppo del codice: 
 * Ogni macchina per ogni periodo di noleggio ha un prezzo di base uguale
 * Si noleggiano solo PORSCHE,AUDI,FIAT con due modelli ciascuno
 * Gli optional su ogni veicolo hanno un costo fisso
 */

public class Main {
	public static void main(String[] args) {
		
	   //Crea due auto nuove
	   AutoFactory auto1 = new AutoFactory.AutoBuilder("AA 111 AA", 2020, Marca.PORSCHE, Modello."CAYENNE", Condizione.NUOVA, Stato.DISPONIBILE, 0 ).build();
	   AutoFactory auto2 = new AutoFactory.AutoBuilder("AA 111 AB", 2020, Marca.PORSCHE, Modello."911" , Condizione.NUOVA, Stato.DISPONIBILE, 0 ).build();
	   
	   //Crea la lista delle auto a cui aggiungere le due auto
	   List<Auto> listaAuto = new vector<>();
	   
	   //Aggiunge le due auto alla lista dei veicoli
	   Ztreh AziendaZtreh = new Ztreh(listaAuto);
	   AziendaZtreh.aggiungiAuto(auto1);
	   AziendaZtreh.aggiungiAuto(auto2);
	   
	   //Cerca le PORSCHE 911 immatricolate nel 2020 nuove
	   AziendaZtreh.elencoVeicoliLiberi(
			new HaQuattroCaratteristiche<> (new QuestaMarca(PORSCHE), 
											new QuestoModello ("911"),
											new QuestAnno (2020),
											new QuestaCondizione(NUOVA)));
		
		//Associamo alla Porsche 911 il prezzo della Kasko e dell'RCA
		AziendaZtreh.memorizzaRataOptional("Rca", Modello."PORSCHE", Marca."911", 150);
		AziendaZtreh.memorizzaRataOptional("Kasko", Modello."PORSCHE", Marca."911", 250);
		
		//Associamo alla Porsche 911 il prezzo della rata base mensile
		AziendaZtreh.memorizzaRataBase(auto2, "Mensile", 1000);
		
		//Associamo alla Porsche 911 il prezzo del riscatto attuale
		AziendaZtreh.memorizzaRiscatto(auto2, "Mensile");
		
		//Calcoliamo il preventivo per l'RCA e la Kasko su una porsche 911 per un mese di noleggio
		List<String> listaOptional = new vector<>();
		listaOptional.add("RCA");
		listaOptional.add("Kasko");
		AziendaZtreh.preventivo(auto2,"Mensile",listaOptional);
		
		//Calcoliamo quanto ci costerebbe chiudere il noleggio anticipato di 5 giorni
		NoleggioFactory PrimoNoleggio = new NoleggioFactory.NoleggioBuilder(auto2, "Mensile", 01/01/20, 31/01/20).build();
		AziendaZtreh.calcolaChiusuraNoleggio(PrimoNoleggio, 1900, 26/01/20);
	}
}
