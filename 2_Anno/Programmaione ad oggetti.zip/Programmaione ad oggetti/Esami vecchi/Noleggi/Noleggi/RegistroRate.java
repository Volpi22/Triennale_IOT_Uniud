/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 //Rappresenta il registro delle rate di noleggio
 public class RegistroRate{
	 
	 //Associa ad ogni auto il suo costo di noleggio mensile
	 private HashMap<Auto targa, int prezzo> prezzoBaseMensile;
	 
	 //Associa ad ogni auto il suo costo di noleggio trimestrale
	 private HashMap<Auto targa, int prezzo> prezzoBaseAnnuale;
	 
	 //Associa ad ogni auto il suo costo di noleggio triennale
	 private HashMap<Auto targa, int prezzo> prezzoBaseTriennale;
	 
	 //Associa ad ogni auto il suo prezzo di riscatto
	 private HashMap<Auto targa, int prezzo> prezzoRiscatto;
	 
	 //Associa ad ogni tipo di auto il suo prezzo mensile di ogni optional
	 private HashMap<String marcaModelloOptional, int prezzo> prezzoOptional;
 }