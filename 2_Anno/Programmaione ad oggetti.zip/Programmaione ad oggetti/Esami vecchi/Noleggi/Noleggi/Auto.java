/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta l'auto e le sue caratteristiche
 public class Auto{
	 
	private String targa;
	private int annoImmatricolazione;
	private Marca marca;
	private Modello modello;
	private Condizione condizione;
	private Stato stato;
	private int chilometraggio;
	
	public Auto(String targa, int annoImmatricolazione, 
				Marca marca, Modello modello, Condizione condizione, Stato stato, int chilometraggio){
		this.targa = targa;
		this.annoImmatricolazione =	annoImmatricolazione;
		this.marca = marca;
		this.modello = modello;
		this.condizione = condizione;
		this.stato = stato;
		this.chilometraggio = chilometraggio;
	}
	
	//Restituisce la targa dell'auto
	public String targa(){
		return this.targa;
	}
	
	//Restituisce la marca dell'auto
	public Marca marca(){
		return this.marca;
	}
	
	//Restituisce il modello dell'auto
	public Modello modello(){
		return this.modello;
	}
	
	//Restituisce l'anno di immatricolazione dell'auto
	public int annoImmatricolazione(){
		return this.annoImmatricolazione;
	}
	
	//Restituisce la condizione dell'auto
	public Condizione condizione(){
		return this.condizione;
	}
	
	//Restituisce il chilometraggio dell'auto
	public Condizione chilometraggio(){
		return this.chilometraggio;
	}
	 
 }