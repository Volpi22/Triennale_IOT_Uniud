/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta i noleggi in corso
 public class Noleggi{

	private Auto auto;
	private Stato statoNoleggio = NOLEGGIATO;
	
	private String durata;
	private Date dataInizioNoleggio;
	private Date dataFineNoleggio;
	
	public Noleggi(Auto auto, String durata, Date dataInizioNoleggio, Date dataFineNoleggio){
		this.auto = auto;
		this.durata = durata;
		
		this.dataInizioNoleggio = dataInizioNoleggio;
		this.dataFineNoleggio = dataFineNoleggio;
	}
	
	//Restituisce lo stato del noleggio
	public StatoNoleggio osservaNoleggio(){
        return this.statoNoleggio;
    }
 }