/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public class QuestoModello implements CaratteristicaAstratta<Auto>{
	 private Modello modello;
	 
	 public QuestoModello(Modello modello){
		 this.modello = modello;
	 }
	 
	 //Restituisce se un'auto è di un certo modello
	 @Override
	 public boolean èSoddisfatta(Auto auto){
		return auto.modello() == modello;
	 }
 }