/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public class QuestaCondizione implements CaratteristicaAstratta<Auto>{
	 private Condizione condizione;
	 
	 public QuestaCondizione(Condizione condizione){
		 this.condizione = condizione;
	 }
	 
	 //Restituisce se un'auto è nella condizione specificata
	 @Override
	 public boolean èSoddisfatta(Auto auto){
		return auto.condizione() == condizione;
	 }
 }