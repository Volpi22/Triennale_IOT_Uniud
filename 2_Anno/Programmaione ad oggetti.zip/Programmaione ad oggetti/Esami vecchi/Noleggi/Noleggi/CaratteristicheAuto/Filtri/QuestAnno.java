/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public class QuestAnno implements CaratteristicaAstratta<Auto>{
	 private Auto annoImmatricolazione;
	 
	 public QuestAnno(Auto annoImmatricolazione){
		 this.annoImmatricolazione = annoImmatricolazione;
	 }
	 
	 //Restituisce se un'auto è stata immatricolata in un certo anno
	 @Override
	 public boolean èSoddisfatta(Auto auto){
		return auto.annoImmatricolazione() == annoImmatricolazione;
	 }
 }