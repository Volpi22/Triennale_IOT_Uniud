/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public interface CaratteristicaAstratta <T>{
	 /**
     * Restituisce true se una determinata caratteristica è soddisfatta dall'ogetto t
     */
    boolean èSoddisfattaDa(T t);
 }