/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public class HaQuattroCaratteristiche<T> implements CaratteristicaAstratta<T>{
	 
	 public HaDueCaratteristiche(CaratteristicaAstratta<T> prima, CaratteristicaAstratta<T> seconda,
								 CaratteristicaAstratta<T> terza, CaratteristicaAstratta<T> quarta) {
        this.prima = prima;
        this.seconda = seconda;
		this.terza = terza;
		this.quarta = quarta;
    }
	/**
     * Restituisce true se quattro caratteristiche sono soddisfatte
     */
    @Override
    public boolean èSoddisfattaDa(T t) {
        return prima.èSoddisfattaDa(t) && seconda.èSoddisfattaDa(t)
			&& terza.èSoddisfattaDa(t) && quarta.èSoddisfattaDa(t);
    }
 }