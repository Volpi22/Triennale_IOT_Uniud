/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public interface FiltroAstratto<T>{
    /**
     * Restituisc tutti gli elementi ogettiDaFiltrare che soddisfano una certa caratteristica
     */
    Stream<T> filtra(List<T> ogettiDaFiltrare, CaratteristicaAstratta<T> caratteristica);
}