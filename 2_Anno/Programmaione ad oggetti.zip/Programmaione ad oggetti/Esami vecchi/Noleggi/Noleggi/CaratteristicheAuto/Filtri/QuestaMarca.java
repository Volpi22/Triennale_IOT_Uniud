/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public class QuestaMarca implements CaratteristicaAstratta<Auto>{
	 private Marca marca;
	 
	 public QuestaMarca(Marca marca){
		 this.marca = marca;
	 }
	 
	 //Restituisce se un'auto è di una certa marca
	 @Override
	 public boolean èSoddisfatta(Auto auto){
		return auto.marca() == marca;
	 }
 }