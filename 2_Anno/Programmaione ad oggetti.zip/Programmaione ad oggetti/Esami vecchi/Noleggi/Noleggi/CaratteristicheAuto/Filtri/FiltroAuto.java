/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 
 public class FiltroAuto implements FiltroAstratto<Auto>{
    @Override
    public Stream<Auto> filtra(List<Auto> ogettiDaFiltrare, CaratteristicaAstratta<Auto> caratteristica){
		return oggettiDaFiltrare.stream().filter(auto -> caratteristica.èSoddisfatta(auto));
	}
}