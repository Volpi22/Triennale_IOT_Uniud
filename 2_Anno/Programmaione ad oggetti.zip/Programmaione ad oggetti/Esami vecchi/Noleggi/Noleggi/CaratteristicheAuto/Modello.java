/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta il modello di tale auto
 public class Modello{
	 
	private String modello;
	
	public Modello(String modello){
		this.modello = modello;
	}
 }