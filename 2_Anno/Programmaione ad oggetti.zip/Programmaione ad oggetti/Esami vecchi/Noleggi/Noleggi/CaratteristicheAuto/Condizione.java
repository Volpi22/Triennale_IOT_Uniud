/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta la condizione dell'auto, se sia nuova o già stata usata
 public enum Condizione{
	NUOVO,USATO
 }