/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta lo stato attuale della macchina, se noleggiata o disponibile al noleggio
 public enum Stato{
	NOLEGGIATA,DISPONIBILE
 }