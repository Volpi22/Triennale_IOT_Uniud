/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta la marca dell'auto con rispettive caratteristiche 
 public class Marca{
	private String marca;
	private Fascia fascia;
	
	public Marca(String marca){
		this.marca = marca;
	}
 }