/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 24/09/21 
 */
 //Rappresenta l'azienda di noleggio delle auto
 public class Ztreh{
	 
	 private List<Auto> listaAuto;
	 
	 public Ztreh(List<Auto> listaAuto, RegistroRate listino){
		 this.listaAuto = listaAuto;
	 }
	 
	 /**
	 * Cerca nell'elenco di tutti i veicoli se c'è qualche veicolo che soddisfa
	 * tutte le caratteristiche richieste dal cliente
	 * @param caratteristicheAuto rappresenta tutte le caratteristiche che l'auto deve soddisfare
	                              N.B. si possono combinare 4 caratteristiche con HaQuattroCaratteristiche
	 * @return tutte le auto che soddisfano la ricerca
	 * @throws NessunaAutoDisponibileException se nessuna auto ha tutte le caratteristiche indicate
	 */
	 Stream<Auto> elencoVeicoliLiberi (CaratteristicaAstratta<Auto> caratteristicheAuto)
				throws NessunaAutoDisponibileException {
				FiltroAstratto<Auto> filtroAuto = new FiltroAuto();
				Stream<Auto> risultato = filtroAuto.filtra(listaAuto, caratteristicheAuto)
				 if(risultato == null){
					throw new NessunaAutoDisponibileException();
        }
	 }
	 
	 /**
	 * Data un'auto,una durata e una lista di optional produce quanto costerebbe tale auto
	 * @param auto rappresenta l'auto che il cliente vuole noleggiare dalla lista delle auto disponibili
	 * @param durata rappresenta per quanto vuole noleggiare tale veicolo il cliente
					 N.B. tale valore può essere solo Mensile, Annuale o Triennale
	 * @param optional è una lista di optional fra quelli messi a disposizione dall'azienda
	 * @return il costo del preventivo calcolato con tali specifiche
	 */
	 public int preventivo(Auto auto, String durata, List<Optional> optional){
		if(durata == "Mensile"){
			return ( RegistroRate.prezzoBaseMensile.get(auto.targa()) + 
					 costoTotaleOptional(auto, optional, durata));	
		}
		else if(durata == "Annuale"){
			return ( RegistroRate.prezzoBaseAnnuale.get(auto.targa()) + 
		         costoTotaleOptional(auto, optional, durata));
		}
		else{
			return ( RegistroRate.prezzoBaseTriennale.get(auto.targa()) + 
		         costoTotaleOptional(auto, optional, durata));
		}				 
	 }
	 
	 /**
	 * Calcola il costo totale di una lista di optional desiderati sul veicolo
	 * @param optional è una lista di optional fra quelli messi a disposizione dall'azienda
	 * @param auto rappresenta l'auto su cui si vuole montare gli optional
	 * @param durata rappresenta la durata del noleggio su cui calcolare i costi
	 * @return il costo complessivo calcolato con tali optional
	 */
	 public int costoTotaleOptional(Auto auto, List<Optional> Optional, String durata) {}
	 
	 /**
	 * Data un'auto,una durata e un prezzo, associa a tale auto quel prezzo come rata base del noleggio
	 * @param auto rappresenta l'auto a cui associare il prezzo di noleggio
	 * @param durata rappresenta la durata del noleggio a cui associare il prezzo
					 N.B. tale valore può essere solo Mensile, Annuale o Triennale
	 * @param prezzo rappresenta il prezzo di tale noleggio
	 */
	 public void memorizzaRataBase(Auto auto, String durata, int prezzo){
		if(durata == "Mensile"){
			RegistroRate.prezzoBaseMensile.put(auto.targa(), prezzo);
		}
		else if(durata == "Annuale"){
			RegistroRate.prezzoBaseAnnuale.put(auto.targa(), prezzo);
		}
		else{
			RegistroRate.prezzoBaseTriennale.put(auto.targa(), prezzo);
		}
	 }
	 
	 /**
	 * Data un'auto e i km percorsi, aggiorna il suo chilometraggio
	 * @param auto rappresenta l'auto di cui aggiornare il chilometraggio
	 */
	 public void aggiornaChilometraggio(Auto auto, int km){}
	 
	 /**
	 * Data un'auto tramite i suoi km percorsi calcola il prezzo del riscatto
	 * e calcola anche eventuali costi extra per percorrenze in eccesso
	 * @param auto rappresenta l'auto di cui andare ad aggiornare il prezzo del riscatto
	 */
	 public void aggiornaRiscatto(Auto auto){}
	 
	 /**
	 * Data un'auto aggiorna il prezzo del suo riscatto in seguito al noleggio
	 * @param auto rappresenta l'auto di cui andare ad aggiornare il prezzo del riscatto
	 * @param durata rappresenta la durata del noleggio a cui associare il prezzo di ricatto a seguito
					 N.B. tale valore può essere solo Mensile, Annuale o Triennale
	 */
	 public int memorizzaRiscatto(Auto auto, String durata){
		 if (durata == "Mensile"){
			 aggiornaChilometraggio(auto, 2000);
			 aggiornaRiscatto(auto);
			 return RegistroRate.prezzoRiscatto(auto.targa);
		 }
		 else if (durata == "Annuale"){
			 aggiornaChilometraggio(auto, 25000);
			 aggiornaRiscatto(auto);
			 return RegistroRate.prezzoRiscatto(auto.targa);
		 }
		 else{
			 aggiornaChilometraggio(auto, 60000);
			 aggiornaRiscatto(auto);
			 return RegistroRate.prezzoRiscatto(auto.targa);
		 }
	 }
	 
	 /**
	 * Data uno specifico modello di auto fra quelle a disposizione dall'azienda di noleggio 
	 * ci associa ad un optional il prezzo
	 * @param optional rappresenta l'optional a cui associare il prezzo
					   N.B. l'optional inserito dev'essere uno fra il seguente elenco: 
					        AssistenzaStradale, CambioGomma, Kasko, Pneumatici, RCA, TagliandiINclusi
	 * @param marca  rappresenta la marca dell'auto su cui mettere l'optional
	                 N.B. la marca inserito dev'essere uno fra il seguente elenco: 
					      Porsche, Audi, Fiat
	 * @param modello rappresenta il modello dell'auto su cui mettere l'optional
	                  N.B. il modello inserito dev'essere uno fra il seguente elenco: 
					       Porsche: Cayenne,911
						   Audi: A3, A4
						   Fiat: Panda, Punto
	 * @param prezzo rappresenta il prezzo da associare all'optional su un determinato tipo di macchina 
	 */
	 public void memorizzaRataOptional(String optional, Marca marca, Modello modello, int prezzo){
		 RegistroRate.prezzoOptional.put(marca + " " + modello + " " + optional, prezzo);
	 }
	 
	 /**
	 * Dato un noleggio e i dati di chiusura, calcola le penalità del noleggio
	 * @param noleggio rappresenta un noleggio
	 * @param chilometraggio rappresenta i km attualmente percorsi dal veicolo 
	 * @param data rappresenta la data di chiusura del noleggio 
	 * @return il prezzo delle penalità da pagare
	 */
	 private int calcolaPenalità(Noleggio noleggio, int chilometraggio, Date dataFine){}

	 /**
	 * Dato il codice di un noleggio attivo, la sua percorrenza e la data di chiusura
	 * calcola il costo finale di chiusura del noleggio
	 * @param noleggio rappresenta un noleggio
	 * @param chilometraggio rappresenta i km attualmente percorsi dal veicolo 
	 * @param data rappresenta la data di chiusura del noleggio 
	 * @return il prezzo di chiusura del noleggio dopo aver considerato tutti i costi
	 * @throws NoleggioNonAttivoException se il noleggio richiesto non è attivo
	 */
	 public int calcolaChiusuraNoleggio(Noleggi noleggio, int chilometraggio, Date data)
				throw NoleggioNonAttivoException {
		if(noleggio.osservaNoleggio()=="NOLEGGIATA"){
			if ((noleggio.durata == "Mensile")
				&&(noleggio.auto.chilometraggio+2000<=chilometraggio)
					 &&(noleggio.dataFineNoleggio==data))
						return 0;
			else if ((noleggio.durata == "Annuale")
					 &&(noleggio.auto.chilometraggio+25000<=chilometraggio)
					 &&(noleggio.dataFineNoleggio==data))
						return 0;
			else if ((noleggio.durata == "Triennale")
					 &&(noleggio.auto.chilometraggio+60000<=chilometraggio)
					 &&(noleggio.dataFineNoleggio==data))
						return 0;
			 else
				 return calcolaPenalità(noleggio,chilometraggio,data);
		}
		else{
			throw new NoleggioNonAttivoException();
		}
	 }
	 
	 //Aggiunge un'auto alla lista delle auto
	 void aggiungiAuto(Auto auto){}
 }

