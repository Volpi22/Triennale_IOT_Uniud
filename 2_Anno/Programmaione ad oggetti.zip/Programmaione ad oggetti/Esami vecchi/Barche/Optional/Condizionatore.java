/**
 * Roberto Borelli
 * Matricola: 147025
 * Programmazione orientata agli ogetti
 * Esame del 04/02/2021
 */

package it.uniud.year2.poo.appello_04_02_RobertoBorelli_mat147025.Optional;

public class Condizionatore implements Optional{

    /**Usatto dall'azienda per regolare la temperatura del condizionatore */
    void regola(){}

    @Override
    public String ottieniDescrizione() {
        return null;
    }

    @Override
    public int costoOptional() {
        return 0;
    }
}
