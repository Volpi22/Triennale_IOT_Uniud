package it.uniud.year2.poo.appello_04_02_RobertoBorelli_mat147025.Eccezioni;

public class StatoNoleggioInvalidoException extends Exception{
}
