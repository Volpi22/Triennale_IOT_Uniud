 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
  /**
 *	Mission: gestisce i giudizi degli esami
 */
 
 public class enum Giudizio{
	INSUFFICIENTE(1), QUASI_SUFFICIENTE(2), SUFFICIENTE(3), BUONO(4), DISTINTO(5), OTTIMO(6);
 }