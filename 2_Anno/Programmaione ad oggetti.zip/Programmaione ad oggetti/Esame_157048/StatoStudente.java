 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce lo stato dello studente
 */
 
 public class enum StatoStudente{
	IN_CORSO(1), FUORI_CORSO(2);
 }