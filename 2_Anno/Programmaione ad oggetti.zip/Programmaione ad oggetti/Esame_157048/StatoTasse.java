 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce lo stato del pagamento delle tasse
 */
 
 public class enum StatoTasse{
	PAGATE(1), NON_PAGATE(2);
 }