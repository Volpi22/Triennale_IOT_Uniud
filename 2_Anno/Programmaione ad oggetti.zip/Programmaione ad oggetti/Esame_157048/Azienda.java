 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: Questa classe gestisce un software universitario per la gestione degli studenti e della loro carriera universitaria
 */
 public class Azienda {
	 
	private list<Studente> listaStudenti;
	private list<Appello> listaAppelli;
	 
	public Azienda (list<Studente> listaStudenti, list<Appello> listaAppelli){
		this.listaStudenti = listaStudenti;
		this.listaAppelli = listaAppelli;
	}

	/**
	*	Mission: Iscrive un determinato studente ad un determinato appello segnalando eventualui anomalie
	*	@param studente REQUIRED NOT NULL, rappresenta lo studente che si vuole iscrivere all'appello
	*	@param appello REQUIRED NOT NULL, rappresenta un appello dell'università
	*	@throws EsameGiaSostenutoException se l'esame è gia stato sostenuto
	*			PreRequisitiMancantiException se mancano i prerrequisiti per sostenere l'esame
	*			StatoTasseIrregolareException se lo studente non è in regola con le tasse
	*/
	public void iscrivi(Studente studente, Appello appello)
				throws EsameGiaSostenutoException, 
					   PreRequisitiMancantiException,
					   StatoTasseIrregolareException
				{
		if(studente.verificaPagamentoTasse()==PAGATE){
			if(studente.verificaPrerequisiti(appello)==TRUE){
				if(studente.verificaEsame(appello)==FALSE){
					appello.aggiungiPartecipante(studente);
				}
				else{
					throw new EsameGiaSostenutoException();
				}
			}
			else{
				throw new PreRequisitiMancantiException();
			}
		}
		else{
			throw new StatoTasseIrregolareException();
		}
	}
	
	/**
	*	Mission: Dato uno studente e l'appello a cui ha partecipato assieme al voto e al giudizio ricevuti permette di calcolare
	*			 il voto complessivo ricevuto dell'esame
	*	@param studente REQUIRED NOT NULL, rappresenta lo studente che ha svolto l'esame
	*	@param appello REQUIRED NOT NULL, rappresenta un esame del percorso accademico
	*	@param voto REQUIRED NOT NULL, rappresenta il voto assegnato al quiz dell'esame
	*	@param giudizio REQUIRED NOT NULL, rappresenta il giudizio assegnato all'esame
	*	@return il voto complessivo dell'esame sostenuto in trentesimi
	*	@throws StudenteNonIscrittoException se lo studente non ha svolto tale esame
	*/
	public int valuta(Studente studente, Appello appello, int votoQuiz, Giudizio giudizio)
			   throws StudenteNonIscrittoException
			   {
		if(appello.verificaIscrizione(studente)==TRUE){
				appello.calcolaVoto(votoQuiz, giudizio);
		}
		else{
			throw new StudenteNonIscrittoException();
		}
	}
	
	/**
	*	Mission: Dato uno studente permette di calcolare la media aritmetica dei voti ottenuti durante il percorso accademico
	*			 e i CFU ottenuti svolgendo tali esami
	*	@param studente REQUIRED NOT NULL, rappresenta lo studente di cui andare a verificare la media aritmetica e i CFU
	*	@return una stringa contenente la media aritmetica e i CFU sostenuti dallo studente
	*	@throws NessunEsameAncoraSostenutoException se lo studente non ha ancora sostenuto alcun esame
	*/
	public String calcolaVotoMedio(Studente studente)
				  throws NessunEsameAncoraSostenutoException
				  {
		if(studente.esamiSostenuti!=NULL){
			return "Lo studente ha una media aritmetica di " + studente.calcolaMediaPesata() +
			" e ha sostenuto un totale di " + studente.calcolaCfuTotali();
		}
		else{
			throw new NessunEsameAncoraSostenutoException();
		}
	}
	
}