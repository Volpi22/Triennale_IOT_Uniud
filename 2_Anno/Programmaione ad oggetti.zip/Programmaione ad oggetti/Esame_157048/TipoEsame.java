 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce il tipo di esame
 */
 
 public class enum TipoEsame{
	IN_PRESENZA(1), A_DISTANZA(2);
 }