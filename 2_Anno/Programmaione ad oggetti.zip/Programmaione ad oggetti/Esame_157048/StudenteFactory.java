 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission:Factory per studente
 */
 
 public class StudenteFactory{
 	 private String nome;
	 private String cognome;
	 private String matricola;
	 private Date dataImmatricolazione;
	 
	 public Studente(StudenteBuilder studenteBuilder){
	 this.nome = studenteBuilder.nome;
	 this.cognome = studenteBuilder.cognome;
	 this.matricola = studenteBuilder.matricola;
	 this.dataImmatricolazione = studenteBuilder.dataImmatricolazione;
	}
 }
 
 static class StudenteBuilder{
 	 private String nome;
	 private String cognome;
	 private String matricola;
	 private Date dataImmatricolazione;
	 
	 public StudenteBuilder(String nome, String cognome, String matricola, Date dataImmatricolazione){
		this.nome = nome;
		this.cognome = cognome;
		this.matricola = matricola;
		this.dataImmatricolazione = dataImmatricolazione;
	 }
	 public Studente build(){
		return new Studente(this);
	}
 }