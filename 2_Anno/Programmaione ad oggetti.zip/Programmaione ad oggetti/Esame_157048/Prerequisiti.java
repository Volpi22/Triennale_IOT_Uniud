/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: classe che contiene le specifiche dei prerequisiti per le iscrizioni ad un corso
 */
 public class Prerequisiti{}