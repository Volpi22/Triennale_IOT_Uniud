/**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: classe che gestisce i dati del corso di laurea triennale
 */
 public class CorsoTriennale implements Corso{
	
	public Docente docenteTitolare;
	public String informazioni;
	public list<Requisiti> prerequisiti;
	public int CFU;
	
 }