 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce il pagamento delle tasse
 */
 
 public class AppelloFactory{
	private Date dataAppello;
	private Corso corsoDiLaurea;
	private TipoEsame tipoEsame;
	
		public Appello(AppelloBuilder appelloBuilder{
		this.dataAppello = appelloBuilder.dataAppello;
		this.corsoDiLaurea = appelloBuilder.corsoDiLaurea;
		this.tipoEsame = appelloBuilder.tipoEsame;
	}
 }
 
static class AppelloBuilder{
	private Date dataAppello;
	private Corso corsoDiLaurea;
	private TipoEsame tipoEsame;
	
		public AppelloBuilder(Date dataAppello, Corso corsoLaurea, TipoEsame tipoEsame){
		this.dataAppello = dataAppello;
		this.corsoDiLaurea = corsoDiLaurea;
		this.tipoEsame = tipoEsame;
	}
	 
	 public Appello build(){
		return new Appello(this);
	}
 }