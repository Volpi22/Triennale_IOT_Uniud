 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: interfaccia che gestisce i dati del corso di laurea
 */
 
 public interface Corso{ 
	
	 /**
	 *	Mission: restituisce i crediti del corso
	 */	
	public int valoreCrediti();
	
	 /**
	 *	Mission: restituisce i prerequisiti del corso
	 */
	public list<Prerequisiti> prerequisitiRichiesti(){}
 }