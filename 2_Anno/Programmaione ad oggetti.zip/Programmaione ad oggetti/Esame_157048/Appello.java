 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce i dati dell'appello
 */
 
 public class Appello{
	private list<Studente> listaIscrizioni;
	private list<Prerequisiti> listaPrerequisiti;
	
	private Date dataAppello;
	private Corso corsoDiLaurea;
	private TipoEsame tipoEsame;
	private TipoAppello tipoAppello;
	private Int cfu;
	
	public Appello(Date dataAppello, Corso corsoLaurea, TipoEsame tipoEsame){
		this.dataAppello = dataAppello;
		this.corsoDiLaurea = corsoDiLaurea;
		this.tipoEsame = tipoEsame;
	}
	
	/**
	*	Mission: aggiunge uno studente alla lista degli iscritti all'appello
	*	@param studente REQUIRED NOT NULL, rappresenta lo studente da aggiungere alla lista dell'esame
	*/
	public void aggiungiPartecipante(Studente studente){
		listaIscrizioni.add(studente);
	}
	
	/**
	*	Mission: rimuove uno studente alla lista degli iscritti all'appello
	*	@param studente REQUIRED NOT NULL, rappresenta lo studente da rimuovere dalla lista dell'esame
	*/
	public void rimuoviPartecipante(Studente studente){
		listaIscrizioni.remove(studente);
	}
	
	/**
	*	Mission: verifica che uno studente sia presente nella lista degli iscritti all'appello
	*	@param studente REQUIRED NOT NULL, rappresenta lo studente da verificare l'iscirizione
	*	@return true se lo studente è iscritto, altrimenti false
	*/
	public bool verificaIscrizione(Studente studente){
		Iterator<Studente> iteratore = listaIscrizioni.iterator();
		while (iteratore.hasNext()) {
			Studente s = iteratore.next();
			if (s.equals(studente)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	*	Mission: date le valutazioni dell'esame calcola in base alla tipologia dell'appello il voto
	*	@param votoQuiz REQUIRED NOT NULL, rappresenta il voto ottenuto nel quiz
	*	@param giudizio REQUIRED NOT NULL, rappresenta il giudizio ottenuto all'esame
	*	@return il voto pesato dell'esame 
	*/
	public int calcolaVoto(int votoQuiz, Giudizio giudizio){
		int votoEsame=0;
		if (giudizio == 1 || giudizio == 2) {
            votoEsame = (votoQuiz + 2) / 2;
        } else if (giudizio == 3 || giudizio == 4) {
            votoEsame = (votoQuiz + 5) / 2;
        } else if (giudizio == 5 || giudizio == 6){
            votoEsame = (votoQuiz + 10) / 2;
		}
	}
 }