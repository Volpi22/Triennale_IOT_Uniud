 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: registro delle tasse pagate
 */
 
 public class Tasse{
	private String descrizione;
	private Date dataPagamentoTassa;
	private bool pagata;
 }