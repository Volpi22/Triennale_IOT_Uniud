 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce il tipo di appello
 */
 
 public class enum TipoAppello{
	PROVA_FINALE(1), PROVA_PARZIALE(2), PROVA_ORALE(3);
 }