 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: gestisce le anagrafiche di ogni studente
 *			 conosce la lista dei corsi a cui uno studente è iscritto
 *			 conosce l'anno corrente
 *			 conosce la lista degli esami già sostenuti da un singolo studente
 */
 public class Studente{
	 
	 private list<Corso> iscrizioneCorsi;
	 private list<Appello> esamiSostenuti;
	 private list<Tasse> tasseUniversitarie;
	 private list<Prerequisiti> prerequisitiSvolti;
	 private StatoTasse statoTasse;
	 private StatoStudente statoStudente;
	 
	 private String nome;
	 private String cognome;
	 private String matricola;
	 private Date dataImmatricolazione;
	 
	 private HashMap<Appello appello, int valutazione> registroValutazioni;
	 
	/**
	*	Mission: costruttore per lo studente
	*/
	public Studente(String nome, String cognome, String matricola, Date dataImmatricolazione){
		 this.nome = nome;
		 this.cognome = cognome;
		 this.matricola = matricola;
		 this.dataImmatricolazione = dataImmatricolazione;
	 }
	
	/**
	*	Mission: verifica lo stato delle tasse dello studente
	*	@return lo stato di pagamento delle tasse
	*/
	public StatoTasse verificaPagamentoTasse(){
		return this.statoTasse;
	}
	
	/**
	*	Mission: verifica se lo studente ha i prerequisiti necessari per svolgere un certo appello (se ne ha)
	*	@param appello REQUIRED NOT NULL, rappresenta l'appello di cui verificare se lo studente ha i prerequisiti
	*	@return true se lo studente ha i prerequisiti, false se non li ha
	*/
	public bool verificaPrerequisiti(Appello appello){
		List<Prerequisiti> prerequisitiAppello = appello.getListaPrerequisiti();
		for (Prerequisiti prereqAppello : prerequisitiAppello) {
			boolean trovato = false;
			for (Prerequisiti prereqSvolti : prerequisitiSvolti) {
				if (prereqAppello.equals(prereqSvolti)) {
					trovato = true;
					break;
				}
			}
			if (!trovato) {
				return false;
			}
		}
		return true;
	}
	
	/**
	*	Mission: verifica se lo studente ha già sostenuto un esame nella sua carriera universitaria
	*	@param appello REQUIRED NOT NULL, rappresenta un appello d'esame 
	*	@return true se lo studente ha sostenuto l'appello, altrimenti false 
	*/
	public bool verificaEsame(Appello appello){
		Iterator<Appello> iteratore = esamiSostenuti.iterator();
		while (iteratore.hasNext()) {
			Appello a = iteratore.next();
			if (a.equals(appello)) {
				return true;
			}
		}
		return false;
	}
	 
	/**
	*	Mission: restituisce la media pesata degli esami sostenuti dallo studente
	*	@return la media pesata di tutti gli esami svolti
	*/
	public int calcolaMediaPesata(){
	    int sommaPesi = 0;
        int sommaValutazioni = 0;
        for (Map.Entry<Appello, Integer> entry : registroValutazioni.entrySet()) {
            Appello appello = entry.getKey();
            int valutazione = entry.getValue();
            sommaPesi += appello.getCfu();
            sommaValutazioni += valutazione * appello.getCfu();
        }
        return sommaValutazioni / sommaPesi;
    }
	
	/**
	*	Mission: restituisce i cfu ottenuti da uno studente
	*	@return il numero di cfu sostenuti dallo studente
	*/
	public int calcolaCfuTotali(){
		int cfuTot = 0;
		Iterator<Appello> iteratore = esamiSostenuti.iterator();
		while (iteratore.hasNext()) {
			Appello a = iteratore.next();
			cfuTot += a.getCfu();
		}
		return cfuTot;
	}
 }