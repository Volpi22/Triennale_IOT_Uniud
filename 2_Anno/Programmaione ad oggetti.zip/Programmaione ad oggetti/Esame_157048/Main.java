 /**
 * Davide Volpi
 * Matricola: 157048
 * Programmazione orientata agli ogetti
 * Esame del 08/02/23
 */
 
 /**
 *	Mission: main contenente un esempio di utilizzo delle funzioni obbligatorie alo svolgimento dell'esame
 *  Assunzioni personali sul testo: nel main darò per scontato che i profili di alcune persone saranno già stati creati,
 *									come dei corsi di laurea, degi  appelli e degli esami siano già stati sostenuti, di modo
 *									da rendere la compilazione più semplice
 */
 public class Main {
	public static void main(String[] args) {
		
		//Sono già presenti un elenco di studenti e di appelli all'interno del precedente software 
		//esse3 che verranno immessi nel software Esse4
		
		//Creo il software Esse4
		Azienda Esse4 = new Azienda(elencoStudenti, elencoAppelli)
		
		//Voglio iscrivere lo studente DavideVolpi all'appello di programmazione ad oggetti del 08/02/23
		Esse4.iscrivi(DavideVolpi, OOP_123);
		
		//Lo studente DavideVolpi in seguito allo svolgimento dell'appello OOP_123 ha riscontrato
		//un voto al quizi di 9/10 e un giudizio allo scritto di OTTIMO e vuole sapere il su voto finale
		int votoFinaleOOP = Esse4.valuta(DavideVolpi, OOP_123, 9, OTTIMO);
		
		//Lo studente DavideVolpi ora che ha scoperto il suo ultimo voto vuole sapere quale sia la sua media aritmetica
		String valutazioniTotali = Esse4.calcolaVotoMedio(DavideVolpi);
	}
}