#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int DistanzaEditing(const string& x, const string& y) {
    int m = x.length();
    int n = y.length();

    // Creazione della matrice di distanza
    vector<vector<int>> dp(m + 1, vector<int>(n + 1));

    // Inizializzazione dei valori base
    for (int i = 0; i <= m; ++i)
        dp[i][0] = i;
    for (int j = 0; j <= n; ++j)
        dp[0][j] = j;

    // Calcolo della distanza di editing
    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (x[i - 1] == y[j - 1])
                dp[i][j] = dp[i - 1][j - 1];  // Caratteri uguali, nessuna modifica
            else
                dp[i][j] = 1 + min({ dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1] });
                // Inserimento, cancellazione, sostituzione (prendiamo il minimo dei tre casi)
        }
    }

    return dp[m][n];  // Restituzione del valore di distanza
}

int main() {
    string x, y;
    getline(cin, x);
    getline(cin, y);

    int distanza = DistanzaEditing(x, y);

    cout << "Distanza di editing: " << distanza << endl;

    return 0;
}
