#include <iostream>
#include <string>
#include <vector>
#include <cstring>

using namespace std;

int PeriodoSmart(const string& s)
{
    int n = s.size();
    vector<int> bordo(n + 1);
    bordo[0] = -1;
    for (int i = 0, j = -1; i < n; ++i) {
        while (j >= 0 && s[i] != s[j]) j = bordo[j];
        bordo[i + 1] = ++j;
    }
    if (bordo[n] == 0) {
        return n;
    }
    return n - bordo[n];
}

int PeriodoNaive(string s) {
  int n = s.length();
  for (int p = 1; p <= n; p++) {
    bool is_period = true;
    for (int i = 0; i < n - p; i++) {
      if (s[i] != s[i + p]) {
        is_period = false;
        break;
      }
    }
    if (is_period) {
      return p;
    }
  }
  return n;
}

int main()
{
    string s;
    cout << "Inserisci una stringa: ";
    getline(cin, s);
    int periodo1 = PeriodoNaive(s);
    cout << "Il periodo frazionario (naive) della stringa �: " << periodo1 << endl;

    string g;
    cout << "Inserisci una stringa: ";
    getline(cin, g);
    int periodo2 = PeriodoSmart(g);
    cout << "Il periodo frazionario (smart) della stringa �: " << periodo2 << endl;

    return 0;
}

