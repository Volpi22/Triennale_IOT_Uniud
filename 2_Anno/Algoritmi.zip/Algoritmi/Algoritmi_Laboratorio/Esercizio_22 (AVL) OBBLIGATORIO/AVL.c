#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct node {
    int key;
    char* value;
    int height;
    struct node* left;
    struct node* right;
} Node;


Node* createNode(int key, char* value)  {
    Node* new_node = (Node*)malloc(sizeof(Node));
    new_node->key = key;
    new_node->value = strdup(value);
    new_node->height = 1;
    new_node->left = NULL;
    new_node->right = NULL;
    return new_node;
}


int getHeight(Node* node) {
    if (node == NULL) {
        return 0;
    }
    return node->height;
}


int getBalance(Node* node) {
    if (node == NULL) {
        return 0;
    }
    return getHeight(node->left) - getHeight(node->right);
}


int max(int a, int b) {
    return a > b ? a : b;
}


Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* z = y->left;
    y->left = x;
    x->right = z;
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
    return y;
}


Node* rightRotate(Node* x) {
    Node* y = x->left;
    Node* z = y->right;
    y->right = x;
    x->left = z;
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
    return y;
}


char* findNode(Node* node, int key) {
    if(key == node->key) {
        return node->value;
    } else if(key > node->key) {
        findNode(node->right, key);
    } else if(key < node->key) {
        findNode(node->left, key);
    }
}


Node* balance(Node* node) {
    if (getBalance(node) > 1) {
        if (getBalance(node->left) < 0) {
            node->left = leftRotate(node->left);
        }
        return rightRotate(node);
    } else if (getBalance(node) < -1) {
        if (getBalance(node->right) > 0) {
            node->right = rightRotate(node->right);
        }
        return leftRotate(node);
    } else {
        node->height = max(getHeight(node->left), getHeight(node->right)) + 1;
        return node;
    }
}


Node* insertNode(Node* node, int key, char* value) {
    if (node == NULL) {
        return createNode(key, value);
    }
    if (key < node->key) {
        node->left = insertNode(node->left, key, value);
    } else if (key > node->key) {
        node->right = insertNode(node->right, key, value);
    } else if(key == node->key) {
        strcpy(node->value, value);
        return node;
    }
    return balance(node);
}


Node* removeNode(Node* root, int key) {
    if (root == NULL) {
        return NULL;
    }
    if (key < root->key) {
        root->left = removeNode(root->left, key);
    } else if (key > root->key) {
        root->right = removeNode(root->right, key);
    } else {    // root->key == key
        // la radice non ha figli
        if (root->left == NULL && root->right == NULL) {
            free(root);
            return NULL;
        } else if (root->left == NULL || root->right == NULL) {
        // la radice ha 1 figlio
            Node* temp = (root->left != NULL ? root->left : root->right);
            free(root);
            return temp;
        } else {
        // la radice ha 2 figli
            Node* temp = (root->right);
            while(temp->left != NULL) {
                temp = temp->left;
            }
            root->key = temp->key;
            strcpy(root->value, temp->value);
            root->right = removeNode(root->right, temp->key);
        }
    }
    return balance(root);
}


void clear(Node* node) {
    if(node != NULL) {
        clear(node->left);
        clear(node->right);
        free(node);
    }
}


void print_node(Node* node) {
    int key = node->key;
    char value[20];
    strcpy(value, node->value);
    int height = getHeight(node);
    printf("%d:%s:%d ", key, value, height);
}


void show(Node* node) {
    if(node != NULL) {
        print_node(node);
        show(node->left);
        show(node->right);
    } else {
        printf("%s", "NULL ");
    }
}


void scan_function(Node *node) {
    char str[100];
    while(1) {
        fgets(str, sizeof(str), stdin);
        char* token = strtok(str, " ");
        if(strcmp(token, "insert") == 0) {
            token = strtok(NULL, " ");
            int key = atoi(token);
            token = strtok(NULL, " ");
            char value[20];
            strcpy(value, token);
            node = insertNode(node, key, value);
        } else if(strcmp(token, "remove") == 0) {
            token = strtok(NULL, " ");
            int key = atoi(token);
            node = removeNode(node, key);
        } else if(strcmp(token, "find") == 0) {
            token = strtok(NULL, " ");
            int key = atoi(token);
            printf("%s", findNode(node, key));
        } else if(strncmp(token, "clear", 5) == 0) {
            clear(node);
            node = NULL;
        } else if(strncmp(token, "show", 4) == 0) {
            show(node);
        } else {
            clear(node);
            break;
        }
    }
}


int main() {
    Node* root = NULL;
    int key;
    char value[20];
    scan_function(root);
    return 0;
}