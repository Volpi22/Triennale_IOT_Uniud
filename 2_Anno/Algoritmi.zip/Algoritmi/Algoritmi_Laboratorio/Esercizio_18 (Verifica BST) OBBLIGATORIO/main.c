#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

struct node{
	int key;
	struct node *left, *right;
};

int isBST(struct node *n, int min, int max){
    if(n==NULL)
        return 1;
    if(n->key<min || n->key>max)
        return 0;
    return (isBST(n->left,min, n->key-1) && isBST(n->right,n->key+1, max));
}

#define MAX_LINE_SIZE 10000   // maximum size of a line of input
struct node *readTree(){
	char str[MAX_LINE_SIZE];
	scanf("%s",str);
	if(strcmp(str,"NULL")==0)
        return NULL;
    int key;
    sscanf(str,"%d",&key);

    struct node *n = (struct node *) malloc(sizeof(struct node));
    n->key=key;
    n->left=readTree();
    n->right=readTree();
    return n;

}

int main()
{
    struct node *n=readTree();
    printf("%d\n", isBST(n,INT_MIN, INT_MAX));
    return 0;
}
