import java.util.Stack;
public class Esercizi13_07_20
{
    
    /*
    //Esercizio 5
    private int n;
    private int elements[];
    private int j;
    
    public IntQueue(int c){
        n= 0;
        elements=new int[c];
        j=0;
    }
    public int size(){
        return n;
    }
    public void add(int e){
        if(n<elements.length){
            int i=(j+n)%elements.length;
            elements[i]=e;
            n=n+1;
        }
    }
    public int peek(){
        return elements[j];
    }
    public int poll(){
        int e=elements[j];
        j=(j+1)%elements.length;
        n=n-1;
        return e;
    }
    */
    //Esercizio 3
    public static long rec( int x, int y, int z ) { // 1 ≤ x, y ≤ z
    
     if ( (x == 1) || (y == z) ) {
     return 1;
     } else {
     return rec( x-1, y, z ) + x * rec( x, y+1, z );
     }
     }
     
    public static final int UNKNOWN=-1;
    public static long recMem(int x,int y, int z){
     long [][]mem = new long [x+1][z+1];
     for(int i=0; i<=x;i=i+1){
         for(int j=z; j<=y;j=j-1){
         mem[i][j]=UNKNOWN; 
     }}
     return recRec(x,y,z,mem);
    }
    private static long recRec( int x, int y, int z, long[][] mem) { // 1 ≤ x, y ≤ z
    
     if ( (x == 1) || (y == z) ) {
         mem[x][y]= 1;
     } else {
         mem[x][y]= recRec( x-1, y, z , mem) + x * recRec( x, y+1, z, mem );
     }
     return mem[x][y];
     }
    
    //Esercizio 4
    public static long tessellations( int n, int k ) {
    
         long[] c = new long[ 1 ];
         c[0] = 0;
    
         tessRec( n, k, c );
    
         return c[0];
     }
     public static void tessRec( int n, int k, long[] c ) {
     if ( n < k ) {
         c[0] = c[0] + 1;
     } else {
         tessRec( n-1, k, c );
         tessRec( n-k, k, c );
     }
    }
    public static long tessIter( int n, int k ) {
     long[] c = new long[ 1 ];
     c[0] = 0;
     Stack< int[] > s = new Stack<int[]>() ;
     s.push( new int[]{n,k});
     do {
         int[] f = s.pop();
         if ( n<k ) {
             c[0] = c[0] + 1;
         } else {
              s.push(new int []{f[0]-f[1],f[1]}) ;
              s.push(new int []{f[0]-1,f[1]}) ;
         }
     } while ( ! s.empty() );
     return c[0];
     }
 
}
