public class Esercizi_24_09_19
{
    // Esercizio 3
    public static int commonStretches(String u, String v){
        int n=u.length();
        int value=0;
        int k=0; // tratti uguali
        int i=0; // tratti verticali di u
        int j=0; // tratti verticali di v
        while(k<n){
            if(u.charAt(k)=='0'){
                i=i+1;
            }
            if(v.charAt(k)=='0'){
                j=j+1;
            }
            if((u.charAt(k)==v.charAt(k)&& (i==j))){
                value=value+1;
            }
            else{
                value=value;
            }
            k=k+1;
        }
        return value;
    }
}
