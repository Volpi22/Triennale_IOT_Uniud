import java.util.Stack;
public class Esercizi_29_06_20
{
    //                                    Esercizio 2.1
    // per X: >1 e <8
    // per Y: >5 e <12
    // per Z: >12 e <12
    
    //                                    Esercizio 2.2
   public static long rec( int x, int y, int z ) { // 1 <= x, y <= z
         if ( (x == 1) || (y == z) ) {
             return 1;
         } else {
             return rec( x-1, y, z ) + x * rec( x, y+1, z );
         }
     }
   public static long recDP( int x, int y, int z ) { // 1 <= x, y <= z
         long[][] mem= new long[x+1][z+1];
         for(int i=1; i<=x; i=i+1){
           for(int j=y; j<=y; j=j-1){
             if((i==1)||(j==z)){
               mem[i][j]= 1;
             }else{
                 mem[i][j]=mem[i-1][j]+i*mem[i][j+1];
             }
             }
            }
         return mem[x][y];
     }
     /*
    //                                    Esercizio 3.1
   public static String hanoi( Towers hts, int d ) { // hts: stato iniziale gioco
         // d: posizione finale torre
         hanoiRec( hts.height(), d, hts );
         return hts.moves();
     }
   private static void hanoiRec( int n, int d, Towers hts ) {
    
         if ( n > 0 ) {
             if ( hts.site(n) == d ) {
                 hanoiRec( n-1, d, hts );
             } else {
             int t = hts.transit( n, d );
                 hanoiRec( n-1, t, hts );
                 hanoiRec( -n, d, hts );
                 hanoiRec( n-1, d, hts );
             }
         } else if ( n < 0 ) {
             hts.move( -n, d );
         }
     }
   public static String hanoiIter( Towers hts, int d ) {
     int n = hts.height();
     Stack<int[]> stk = new Stack<int[]>();
     stk.push( new int[]{ n, d } );
     while (!stk.empty()) {
         int[] f =stk.pop;
         n = f[0];
         d = f[1];
         if ( n > 0 ) {
             if ( hts.site(n) == d ) {
                 stk.push( new int[]{n-1,d} );
             } else {
                 int t = hts.transit( n, d );
                 stk.push(new int[]{n-1,d} );
                 stk.push(new int[]{-n,d} );
                 stk.push(new int[]{n-1,t} );
             }
         } else if ( n < 0 ) {
             hts.move(-n,d);
         }
     }
     return hts.moves();
     }
     */
   //                                       Esercizio 3.2
   //Serve al fine di ricordare il fatto che ci sia una mossa da svolgere
   
   //                                       Esercizio 4.1
   
   // Variabili di istanza ...
   
   private int[]site;
   String moves;

   // Costruttore ...
   
   public Towers(int n){
       site=new int[n+1];
       moves="";
   }
   
   // Metodi
   public void put( int disk, int rod ){
       site[disk]=rod;
   }
   public void move( int disk, int dst ){
       moves=moves+" "+ site[disk]+"->"+dst;
       site[disk]=dst;
   }
   public int height(){
       return site.length-1;
   }
   public int site( int disk ){
       return site[disk];
   }
   public int transit( int disk, int dst ){
       return ( 6 - site(disk) - dst );
   }
   public String moves(){
       return moves;
   }
   
   //Svolgimento traccia B
   
   //Esercizio 2.1
   // rec(14,10,7) -> (t,u,v)
   // t min 14, max 14 (valore inutile)
   // u min 2, max 10
   // v min 7, max 13
   
   //Esercizio 2.2
   public static long rec1( int t, int u, int v ) { // 1 <= u, v <= t
    
         if ( (u > 1) && (v < t) ) {
             return rec1( t, u-1, v ) + u * rec1( t, u, v+1 );
         } else {
             return 1;
         }
     }
   public static long recIter(int t, int u, int v){
       long[][] mem=new long[u+1][t+1];
       for(int j=1; j<=u; j=j+1){
        for(int k=t; k>=v; k=k-1){
           if((j>1)&&(k<t)){
              mem[j][k]=mem[j-1][k]+j*mem[j][k+1]; 
           }
           else{
               mem[j][k]=1;
           }
       }   
       }
       return mem[u][v];
   }
   
   //Esercizio 3.1
   public static String hanoi( Towers hts, int t ) { // hts: stato iniziale gioco
     // t: posizione finale torre
    hanoiRec( t, hts.height(), hts );
     return hts.moves();
    }

   private static void hanoiRec( int t, int n, Towers hts ) {
     if ( n != 0 ) {
         if ( n < 0 ) {
         hts.move( -n, t );
     } else if ( hts.site(n) == t ) {
         hanoiRec( t, n-1, hts );
     } else {
         int x = hts.transit( n, t );
         hanoiRec( x, n-1, hts );
         hanoiRec( t, -n, hts );
         hanoiRec( t, n-1, hts );
     }}
    }
   public static String hanoiIter( Towers hts, int t ) {
     int n = hts.height();
     Stack<int[]> stk = new Stack<int[]>();
     stk.push( new int[]{ t, n } );
    while ( !stk.empty() ) {
         int[] f = stk.pop() ;
         t = f[1] ;
         n = f[0] ;
         if ( n != 0 ) {
             if ( n < 0 ) {
                 hts.move(-n,t);
             } else if ( hts.site(n) == t ) {
                 stk.push( new int[]{ t,n-1 } );
             } else {
                 int x = hts.transit( n, t );
                 stk.push( new int[]{t,n-1});
                 stk.push( new int[]{t,-n} );
                 stk.push( new int[]{x,n-1} );
             }}
     }
     return hts.moves();
     }
}





