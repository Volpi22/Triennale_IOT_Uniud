import java.util.Stack;
import java.util.Vector;
public class Esercizi_03_09_19
{
 public static Vector<String> perm( String u ) { // u non vuota
     Vector<String> p = new Vector<String>();
     permRec( u, 0, p );
     return p;
    }
     public static void permRec( String u, int k, Vector<String> p ) {
     int n = u.length();
     if ( k == n-1 ) {
     p.add( u );
     } else {
     permRec( u, k+1, p );
     for ( int i=k+1; i<n; i=i+1 ) {
     String v = u.substring( 0, k ) + u.substring( i, i+1 ) + u.substring( k+1, i )
     + u.substring( k, k+1 ) + u.substring( i+1, n );
     permRec( v, k+1, p );
     }}
 }   
 public static Vector<String> permIter( String u ) { // u non vuota
     Vector<String> p = new Vector<String>();
     int n = u.length(), k;
     Stack<String> s = new Stack<String>();
     Stack<Integer> t = new Stack<Integer>();
     s.push( u ); t.push( 0 ); 
     do {
         k=t.pop(); u=s.pop();
         if ( k == n-1 ) {
          p.add( u );
         } else {
          s.push(u); t.push(k+1);
          for(int i=k+1; i<n;i=i+1){
              String v = u.substring( 0, k ) + u.substring( i, i+1 ) + u.substring( k+1, i )
                         + u.substring( k, k+1 ) + u.substring( i+1, n );
              s.push(v); t.push(k+1);
          }
         }
     } while ( !s.empty() );
     return p;
 }
 /*
  * Esercizio 5 
  */
  public static int pow4( int n ) { // Pre: n > 0
     int x = 0 , y = 0;
     int z = 1 , u = 1 ;
     while ( x < u ) {              // Inv: (x ≤ n2) ∧ (y = x2) ∧ (z = 2x+1) ∧ (u = min(y+z,n2))
         x = x + 1;
         y = y + z ;
         z = z + 2 ;
         if ( (y+z)<=(n*n) ) {
         u = y + z;
     }}
     return y; // Post: y = n4
     }
 /*
  * Esercizio 3
  */
 public static long q( int i, int j, int k ) { // i, j, k >= 0
     long x = ( i < 2 ) ? i : q( i-2, j, k );  // ?= se allora ; : = sennò
     long y = ( j < 2 ) ? j : q( i, j-2, k );
     long z = ( k < 2 ) ? k : q( i, j, k-2 );
     long m = x + y + z;
     return ( m == 0 ) ? 1 : m;
     }
}
