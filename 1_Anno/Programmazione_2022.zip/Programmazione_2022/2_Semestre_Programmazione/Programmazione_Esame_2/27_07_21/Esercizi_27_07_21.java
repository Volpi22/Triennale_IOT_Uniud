import huffman_toolkit.*;

public class Esercizi_27_07_21
{
 //Esercizio 3
    // Length of the Longest Damping Subsequence
 public static int llds1( double[] s ) {
     return lldsRec1( s, 0, Double.NaN, Double.NaN ); // NaN = not a number (predefinito per double)
     }
 private static int lldsRec1( double[] s, int i, double u, double v ) {
     if ( i == s.length ) { // coda di s vuota
         return 0;
      } else if ( Double.isNaN(u) || ((Math.min(u,v) < s[i]) && (s[i] < Math.max(u,v))) ) {
        return Math.max( 1+lldsRec1(s,i+1,v,s[i]), lldsRec1(s,i+1,u,v) ); // s[i] può essere scelto o meno
      } else {
             return lldsRec1( s, i+1, u, v ); // s[i] non può essere scelto
     }
    }
    
 public static int llds( double[] s ) {
     int n = s.length;
     int[][][] mem = initStruct( n );
     return lldsRec( s, 0, n, n, mem );
     }
 private static int lldsRec( double[] s, int i, int j, int k, int[][][] mem ) {
     if ( mem[i][j][k] == UNKNOWN ) {
         int n = s.length;
     if ( i == n ) {
         mem[i][j][k] = 0;
     } else if ( j==n || ((Math.min(s[j],s[k]) < s[i]) && (s[i] < Math.max(s[j],s[k]))) ) {
         mem[i][j][k] = Math.max( 1+lldsRec(s,i+1,k,i,mem), lldsRec(s,i+1,j,k,mem) );
     } else {
         mem[i][j][k] = lldsRec( s, i+1, j, k ,mem);
     }}
     return mem[i][j][k];
     }
     private static final int UNKNOWN = -1;
 //Esercizio 4
 public static int huffmanSize( Node root ) {
     return huffmanSizeRec( root, 0 );
     }
 private static int huffmanSizeRec( Node n, int d ) {
     if ( n.isLeaf() ) {
         return d * n.weight();
      } else {
         return huffmanSizeRec( n.left(), d+1 ) + huffmanSizeRec( n.right(), d+1 );
     }
    }
    
 public static int huffmanSizeIter( Node root ) {
     Stack<Frame> stack = new Stack<Frame>();
     stack.push( new Frame(root,0) );
     int hSize = 0;
     do {
         Frame current = stack.pop() ;
         Node n = current.node ;
         int d = current.depth ;
         if ( n.isLeaf() ) {
             hSize = d*n.weight ;
         } else {
             stack.push(new Frame(n.right(),d+1)) ;
             stack.push(new Frame(n.left(),d+1)) ; ;
         }
     } while ( !stack.empty() );
     return hSize;
  }
}
