public class Esercizi_29_01_21
{
    //Esercizio 4
    /*
     *
     * 
     */
 public static long rec( int n, int k ) { // 0 ≤ n ≤ k
     if ( n * (n-k) >= 0 ) {
     return 1;
     } else {
     return rec( n, k-1 ) + rec( k-n, k-1 );
     }
 }
 /*
 public static long rec( int n, int k ) { // 0 ≤ n ≤ k
     if ( n * (n-k) >= 0 ) {
     return 1;
     } else {
     return rec( n, k-1 ) + rec( k-n, k-1 );
     }
 }
 */
 public static long recDP(int n, int k){
     long[][] mem= new long [k+1][k+1];
     for(int j=1; j<=k; j=j+1){
        for(int i=1;i<=j;i=i+1){
         if ( i * (i-j) >= 0 ) {
             mem[i][j] = 1;
         } else {
             mem[i][j] = mem[i][j-1] + mem[j-i][j-1];
         }
      }}
     return mem[n][k];
 }
}
