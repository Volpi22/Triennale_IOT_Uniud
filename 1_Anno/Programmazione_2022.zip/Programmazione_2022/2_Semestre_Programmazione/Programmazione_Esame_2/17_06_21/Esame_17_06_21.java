public class Esame_17_06_21
{
//                                       Esercizio 1.1

public static int llmds(double[] s){
    return llmdsRec( s, 0, 0 );
}
private static int llmdsRec(double[] s,int i, double t){
    if ( i == s.length ) { // i = n : coda di s vuota
         return 0;
    }
    else if((t==0)||((0.5*t<=s[i])&&(s[i]<t))){
        return Math.max( 1+llmdsRec(s,i+1,s[i]), llmdsRec(s,i+1,t) );
    }
    else{
        return llmdsRec( s, i+1, t );
    }
}

//                                      Esercizio 1.2

//I valori che t potrà assumere saranno 7.5, 4.5, 2.7 e i assumerà i valori delle posizioni da 1 a 5

//                                      Esercizio 2.1

private static final int UNKNOWN = -1;
public static int llmdsMem(double[] s){
    
    int n= s.length;
    int[][] mem= new int[n+1][n+1];
    for(int i=0; i<=n; i=i+1){
        for(int j=0; j<=n;j=j+1){
            mem[i][j]=UNKNOWN;
        }
    }
    return llmdsMemRec( s, 0, n, mem );
}
private static int llmdsMemRec(double[] s,int i, int j,int[][]mem ){
    double t=(j==s.length) ? 0 : s[j];
    if(mem[i][j]==UNKNOWN){
        if ( i == s.length ) { // i = n : coda di s vuota
             mem[i][j]=0;
        }
        else if((t==0)||((0.5*t<=s[i])&&(s[i]<t))){
            return Math.max( 1+llmdsMemRec(s,i+1,i,mem), llmdsMemRec(s,i+1,j,mem));
        }
        else{
            return llmdsMemRec( s, i+1, j, mem);
        }}
    return mem[i][j];
}

//                                      Esercizio 3.1

public static String manhattanPath(int[][] manh){
    
    int m = manh.length -1;
    int n = manh[0].length -1;
    
    String path="";
    int i=0;
    int j=0;
    while((i<=m )&&(j<=n)&&(manh[i][j]>0)){
        if(reward(i,j,0)+manh[i+1][j]  >  reward(i,j,1)+manh[i][j+1]){
           i=i+1;
           path=path+"0";
        }
        else{
            j=j+1;
            path=path+"1";
        }
    }
    while(i<m){
        i=i+1;
        path=path+"0";
    }
    while(j<n){
        j=j+1;
        path=path+"1";
    }
    return path;
}
public static int reward(int i, int j, int step){
    return 5;
}

//                                         Esercizio 4.1

// in 4 modi 

//                                         Esercizio 4.2



}