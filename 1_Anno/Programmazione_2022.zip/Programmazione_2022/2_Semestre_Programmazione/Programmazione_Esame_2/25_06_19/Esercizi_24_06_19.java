import java.util.Stack;
public class Esercizi_24_06_19
{
    /*
     //Esercizio 2
 public static int[] ldiff(String u, String v){
     int m=u.length();
     int n=v.length();
     int[][][] mem=new int[m+1][n+1][2];
     for(int i=0; i<=m; i=i+1){
         for(int j=0; j<=n; j=j+1){
             mem[i][j]=null;
            }}
     return ldiffRec(u,v,mem);
 }
 private static int[] ldiffRec( String u, String v, int[][][] mem ) {
    int i=u.length();
    int j=v.length();
    if(mem[i][j]==null){ 
        if ( u.equals("") || v.equals("") ) {
            mem[i][j]= new int[] { u.length(), v.length() };
        } else if ( u.charAt(0) == v.charAt(0) ) {
            mem[i][j]= ldiffRec( u.substring(1), v.substring(1), mem );
        } else {
            int[] x = ldiffRec( u.substring(1), v, mem );
            int[] y = ldiffRec( u, v.substring(1), mem );
        if ( x[0] < y[0] ) {
            mem[i][j]= new int[] { x[0]+1, x[1] };
        } else {
            mem[i][j]= new int[] { y[0], y[1]+1 };
        }}
    }
    return mem[i][j];
 }
 
 
    // Esercizio 4
 public static int intSqrt( int n ) { // Pre: n ≥ 0
     int q = 0, x = 0, y = 1, z = n-1;
     while ( x <= z ) { // Inv: 0 ≤ q ≤ √n , x = q2, y = 2q+1, y+z = n
                        // Term: sqrt(n)-q
         q = q + 1;
         x = x + y;
         y = y + 2;
         z = z - 2;
     }
     return q; // Post: valore restituito: ⎣√n ⎦
     }
     
    // Esercizio 3
 public static long st( int n, int k ) { // n, k > 0
     long[] ct = new long[] { 0 }; // contatore: variabile di stato
     sRec( n, k, 1, ct );
     return ct[0];
     }
     private static void sRec( int n, int k, int q, long[] ct ) {
         if ( (k == 1) || (k == n) ) {
             ct[0] = ct[0] + q;
         } else {
             sRec( n-1, k-1, q, ct );
             sRec( n-1, k, k*q, ct );
         }
 }
 public static long stIter( int n, int k ) { // n, k > 0
     long[] ct = new long[] { 0 };
     Stack<int[]> stack = new Stack<int[]>();
     int[] f = new int[] { n,k,1};
     stack.push( f );
     while ( !stack.empty() ) {
             f = stack.pop();
             if ( (f[1] == 1) || ( f[1]== f[0] ) ) {
                  ct[0] = ct[0] + f[2];
         } else {
             stack.push( new int[] { f[0]-1, f[1], f[1]*f[2] } );
             stack.push( new int[] { f[0]-1, f[1]-1, f[2] } );
             
         }}
     return ct[0] ;
 }
 */
 //Versione 2A
 public static String[] diff(String u, String v){
     int m=u.length();
     int n=v.length();
     String[][][] mem=new String[m+1][n+1][2];
     for(int i=0; i<=m; i=i+1){
         for(int j=0; j<=n; j=j+1){
             mem[i][j]=null;
            }}
     return diffRec(u,v,mem);
 }
 public static String[] diffRec( String u, String v, String[][][] mem) {
     int i=u.length();
     int j=v.length();
     if ( u.equals("") || v.equals("") ) {
        
        mem[i][j]= new String[] { u,v };
    
     } else if ( u.charAt(0) == v.charAt(0) ) {
    
         mem[i][j]= diffRec( u.substring(1), v.substring(1),mem);
    
     } else {
    
         String[] x = diffRec( u.substring(1), v, mem );
         String[] y = diffRec( u, v.substring(1),mem );
    
     if ( x[0].length() < y[0].length() ) {
         mem[i][j]= new String[] { u.charAt(0)+x[0], x[1] };
     } else {
         mem[i][j]= new String[] { y[0], v.charAt(0)+y[1] };
     }}
     return mem[i][j];
    }
 //Versione 3B
 public static long stIter( int n, int k ) { // n, k > 0
     long[] cn = new long[] { 0 };
     Stack<int[]> stack = new Stack<int[]>();
     int[] f = new int[] { 1,n,k };
     stack.push( f );
     while ( !stack.empty() ) {
         f = stack.pop() ;
         if ( (f[2] == 1) || ( f[2]==f[1] ) ) {
             cn[0] = cn[0] + f[0];
         } else {
             stack.push( new int[] { f[2]*f[0] , f[1]-1, f[2] } );
             stack.push( new int[] { f[0] , f[1]-1, f[2]-1 } );
         }
        }
     return cn[0] ;
  }
 public static int intSqrt( int n ) {       // Pre: n ≥ 0
     int x = 0, y = 0, z = 1 , q = 1 ;
     while ( q <= n ) {                     // Inv: 0 ≤ x ≤ √n , y = x2, z = 2x+1, q = y+z
                                            // Term: sqrt(q)-x
     x = x + 1; 
     y = q;
     z = z + 2 ;
     q = q + z ;
     }
    
     return x ; // Post: valore restituito: ⎣√n ⎦
     }
 }
 
 /* q=y+z -> q=x^2+2x+1 -> (x+1)^2 ->q=(x+1)^2 sqrt(q)=x+1 -> sqrt(q)-x=1
  * x>z q^2>z -> n=y+z -> n=2q+1+z < q^2+2q+1=(q+1)^2 ->sqrt(n)<=q+1 q<=sqrt(n)<=q+1 sqrt(n)-q
  */
