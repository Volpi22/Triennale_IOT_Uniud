import java.util.Stack;
public class Esercizi_04_02_20
{
    /*
    (define f ; val: intero
     (lambda (u v x y) ; u, v, x, y ≥ 0 interi
         (cond ((and (= x u) (= y v)) 0)
             ((= x 0) (if (= u 0) 0 1))
             ((= y 0) (if (= v 0) 0 1))
             (else (+ (f u v (- x 1) y) (f u v x (- y 1))))
     )))
 */
 // Esercizio 5
  public static long fIter( int u, int v, int x, int y ) { // u, v, x, y ≥ 0
     long c = 0;
     Stack<int[]> s = new Stack<int[]>();
     s.push( new int[]{x,y} );
     while ( !s.empty() ) {
         int[] r = s.pop();
         x = r[0];
         y = r[1] ;
         if ( (x == u) && (y == v) ) {
         ; // skip: nessuna azione da eseguire
         } else if ( x == 0 ) {
         c = c + 1;
         } else if ( y == 0 ) {
         c = c + 1;
         } else {
         s.push(new int[]{x,y-1});
         s.push(new int[]{x-1,y});
     }
    }
     return c;
 }
}
