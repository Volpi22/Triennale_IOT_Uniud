/*
 * Problema 14
 * Data una sequenza s di n interi positivi, rappresentata da un array, il seguente programma in Java calcola la lunghezza
 * della più lunga sottosequenza di s strettamente crescente (llis: length of the longest increasing subsequence).
 * Una sottosequenza strettamente crescente di s è formata da una selezione dei suoi elementi che, considerati esattamente
 * nell’ordine in cui compaiono in s, determinano una sequenza di interi crescente in senso stretto. Per esempio, in
 * relazione alla sequenza s = <2, 7, 5, 7, 4>, le sottosequenze <2, 4> e <5, 7> sono strettamente crescenti, ma non
 * della lunghezza massima possibile, <2, 5, 7> è una sottosequenze crescente più lunga (di fatto l’unica nel caso
 * considerato), mentre <2, 7, 7> non è strettamente crescente e <2, 4, 5, 7> non è una sottoseaquenza di s perché non
 * è rispettato l’ordine degli elementi.
 * Il programma per llis si basa essenzialmente sulla procedura ricorsiva llisRec, che risolve un problema correlato
 * per una “coda” della sequenza originale s. Più precisamente, llisRec calcola la lunghezza della sottosequenza
 * crescente più lunga relativa agli elementi di s a partire dalla posizione i, corrispondenti cioè all’intervallo di indici
 * compresi fra i e n–1, imponendo l’ulteriore vincolo che gli elementi della sottosequenza debbano essere strettamente
 * maggiori del valore di un parametro aggiuntivo t che funge da soglia. I casi base di llisRec corrispondono a una coda
 * vuota (i = n). Se l’elemento x nella posizione iniziale i non soddisfa il vincolo x > t, allora non può far parte della
 * sottosequenza misurata da llisRec e ci si riconduce direttamente al corrispondente problema per una coda più corta
 * che inizia in posizione i+1. Altrimenti x può far parte o meno della sottosequenza più lunga: se vi fa parte, l’elemento
 * va contato ai fini della lunghezza (1+) e i successivi elementi, da cercare a partire da i+1, devono essere maggiori di x;
 * se invece non vi fa parte il vincolo aggiuntivo resta determinato da t anche quando si restringe la ricerca alla coda che
 * inizia in posizione i+1; si sceglierà poi l’opzione più favorevole in base ai risultati ottenuti ricorsivamente ,
 * confrontando le lunghezze nei due casi.
 * Per quanto riguarda la prima invocazione di llisRec da parte di llis, i = 0 identifica l’intera sequenza e t = 0 non
 * vincola la scelta del primo elemento della sottosequenza poiché tutti gli interi di s sono positivi e quindi maggiori di 0.
 * Di conseguenza, llisRec(s,0,0) calcola precisamente la lunghezza della più lunga sottosequenza crescente di s.
     public static int llis( int[] s ) { // s[i] > 0 per i in [0,n-1], dove n = s.length
         return llisRec( s, 0, 0 );
     }
    
     private static int llisRec( int[] s, int i, int t ) {
         if ( i == s.length ) { // i = n : coda di s vuota
             return 0;
         } else if ( s[i] <= t ) { // x = s[i] ≤ t : x non può essere scelto
             return llisRec( s, i+1, t );
         } else { // x > t : x può essere scelto o meno
             return Math.max( 1+llisRec(s,i+1,s[i]), llisRec(s,i+1,t) );
         }
     }
 * Nella pagina successiva sono riportati i risultati della valutazione del metodo statico llis in alcuni casi esemplificativi;
 * quindi vengono proposti due problemi di programmazione che prevedono l’applicazione della tecnica top-down di memoization.
 * Assumi provvisoriamente che tutti gli elementi di una sequenza di lunghezza n siano minori o ugali a n e scrivi un
 * programma equivalente che applica la tecnica top-down di memoization per realizzare una versione più efficiente di
 * llis, registrando i risultati delle invocazioni ricorsive di llisRec ai fini di un potenziale riutilizzo. Verifica quindi
 * che i risultati ottenuti siano coerenti con i valori calcolati dal programma riportato sopra (a tal fine, una parte degli
 * esempi non possono esseere usati per la verifica poiché incompatibili con l’assunzione fatta).
 * Estendi ora il programma che applica la tecnica top-down di memoization ai casi più generali in cui gli elementi della
 * sequenza possano assumere qualunque valore intero (di tipo int) rappresentabile e verifica che i risultati ottenuti siano
 * sempre coerenti con i valori calcolati dal programma riportato sopra.
 */
public class LLIS
{
 private static int UNKNOWN =-1;
 
 public static int llis( int[] s ) {            // s[i] > 0 per i in [0,n-1], dove n = s.length
     return llisRec( s, 0, 0 );
 }

 private static int llisRec( int[] s, int i, int t ) {
     if ( i == s.length ) {                     // i = n : coda di s vuota
         return 0;
     } else if ( s[i] <= t ) {                  // x = s[i] ≤ t : x non può essere scelto
         return llisRec( s, i+1, t );
     } else {                                   // x > t : x può essere scelto o meno
         return Math.max( 1+llisRec(s,i+1,s[i]), llisRec(s,i+1,t) );
     }
 }

 //Versione Top-Down

 public static int llisMem( int[] s ) {            // s[i] > 0 per i in [0,n-1], dove n = s.length
     int n = s.length;
     int[]mem=new int[n+1];
     for (int i=0; i<=n; i=i+1){
            mem[i]=UNKNOWN;
        }
     return llisMemRec( s, 0, 0, mem );
 }
 private static int llisMemRec( int[] s, int i, int t, int[] mem ) {
     if ( i == s.length ) {                     // i = n : coda di s vuota
         mem[i]= 0;
     } else if ( s[i] <= t ) {                  // x = s[i] ≤ t : x non può essere scelto
         mem[i]= llisRec( s, i+1, t );
     } else {                                   // x > t : x può essere scelto o meno
         mem[i]= Math.max( 1+llisMemRec(s,i+1,s[i],mem), llisMemRec(s,i+1,t, mem));
     }
     return mem[i];
 }
 
 //Versione Top-Down V2
 
 public static int llisMem1 (int[] s) {
   int n= s.length;
   int[][] mem= new int[n+1][n+1];
   for (int i=0;i<(n+1);i++)
     for (int j=0;j<(n+1);j++){
        mem[i][j]=UNKNOWN;
    }
   
   int[] f=new int[n+1];
   for (int i=0;i<n;i++){   //inizializzazione di j secondo istruzioni
      f[i]=s[i];
      f[n]=0;
    }
      
   return llisMemRec1 (f , 0 , n, mem);  //viene passata n come j
 }
 
 private static int llisMemRec1 (int[] s, int i, int j, int[][] mem){
   final int n = s.length;
   if (i == n) {
       return 0;
   } else if (mem[i][j]==UNKNOWN) {
      if (s[i] <= s[j]) {
       mem[i][j]=llisMemRec1(s,i+1,j,mem);
       return mem[i][j];
     } else {
       mem[i][j]=Math.max(1+llisMemRec1(s,i+1,i,mem) , llisMemRec1(s,i+1,j,mem));
       return mem[i][j];
   
     }} else {
     return mem[i][j];
   }
 }
 }
