public class BTR
{
  public static String BtrSucc (String btr) { 
       int n = btr.length();
       char lsb = btr.charAt(n-1);
           if(n ==1){
                if(lsb == '+'){
                    return "+-" ;
                }
                else{
                    return "+";
                }
            }
            else{
                String pre = btr.substring(0, n-1);
                if(lsb == '+'){
                    return BtrSucc(pre) + "-";
                }
                else{
                    if(lsb == '-') {
                        return pre + ".";
                    }
                    else
                        return pre + "+";
                }
            }
    }
    public static StringSList BTR (String btr, int n)
  {
      StringSList fine = StringSList.NULL_STRINGLIST;
      
      for(int i=0; i<n; i++)
       {
          fine=fine.cons(btr);
          btr=BTR.BtrSucc(btr);
      }
      return fine.reverse();
  }
}

