/*
 * Problema 10
 * Definisci in Java una classe StringSList per rappresentare liste di stringhe nello stile di Scheme. 
 * Analogamente alla classe introdotta a lezione per le liste di interi, il protocollo deve prevedere i
 * seguenti costruttori e metodi:
 
     public StringSList() // null
    
     public StringSList( String e, StringSList sl ) // cons
    
     public boolean isNull() // null?
     public String car() // car
    
     public StringSList cdr() // cdr
    
     public StringSList cons( String e ) // cons (modalità alternativa)
    
     public int length() // length
    
     public String listRef( int k ) // list-ref
    
     public boolean equals( StringSList sl ) // equal?
    
     public StringSList append( StringSList sl ) // append
    
     public StringSList reverse() // reverse
    
     public String toString() // visualizzazione testuale
     
* Al fine di verificare le funzionalità della classe StringSList, in un file separato definisci una 
* procedura (metodo statico) che, data una stringa btr (oggetto di tipo String) che rappresenta un intero
* non negativo nella notazione BTR (Balanced Ternary Representation) e dato un intero non negativo n 
* (valore di tipo int), restituisce la lista di n interi consecutivi in notazione BTR, a partire da btr.
* Per esempio, se btr = "+-" e n = 5, la lista risultante deve contenere le cinque stringhe "+-", "+.",
* "++", "+--" e "+-.", nell’ordine. Per generare le successive rappresentazioni in forma BTR applica la
* procedura btrSucc realizzata in Java nell’esercitazione precedente. Infine, operando su liste di 
* diversa lunghezza costruite in questo modo, verifica sperimentalmente che il risultato dell’applicazione
* di ciascuno dei metodi del protocollo pubblico di StringSList sia coerente con quello delle 
* corrispondenti procedure predefinite di Scheme.
*/
public class StringSList
{
    
      public static final StringSList NULL_STRINGLIST = new StringSList();
    
      private final boolean empty;               // oggetti immutabili:
      private final String first;                // variabili di istanza "final"
      private final StringSList rest;
      
    public StringSList() {                  // creazione di una lista vuota
                                            // Scheme: null
        empty = true;
        first = "";                        // valore irrilevante in questo caso
        rest = null;
      }
    public StringSList( String e, StringSList il ) {  // creazione di una lista non vuota:
                                               // Scheme: cons
        empty = false;
        first = e;
        rest = il;
      }
    public boolean isNull() {                // verifica se una lista e' vuota
                                             // Scheme: null?
        return empty;
      }
    public String car() {                       // primo elemento di una lista
                                               // Scheme: car
        return first;                          // si assume: lista non vuota
      }
    public StringSList cdr() {                  // resto di una lista
                                               // Scheme: cdr
        return rest;                           // si assume: lista non vuota
      }
    public StringSList cons( String e ) {          // costruzione di nuove liste
                                               // Scheme: cons
        return new StringSList( e, this );
      }
    public int length() {                    // lunghezza di una lista
                                               // Scheme: length
        if ( isNull() ) {                      // oppure: this.isNull()
          return 0;
        } else {
          return ( 1 + cdr().length() );       // oppure:
        }                                      //   ( this.cdr() ).isNull()
      }
    public String listRef( int k ) {           // elemento in posizione k
                                               // Scheme: list-ref
        if ( k == 0 ) {
          return car();                        // oppure: this.car()
        } else {
          return ( cdr().listRef(k-1) );       // oppure:
                                               //   ( this.cdr() ).listRef(k-1)
         }
       } 
    public boolean equals( StringSList il ) {     // contronto di liste
                                               // Scheme: equal?
        if ( isNull() || il.isNull() ) {
          return ( isNull() && il.isNull() );
        } else if ( car().equals(il.car()) ) {
          return cdr().equals( il.cdr() );
        } else {
          return false;
        }
      }
    public StringSList append( StringSList il ) {  // fusione di liste
                                             // Scheme: append
        if ( isNull() ) {
          return il;
        } else {
          // return new IntSList( car(), cdr().append(il) );
          return ( cdr().append(il) ).cons( car() );
        }
      }
    public StringSList reverse() {              // rovesciamento di una lista
                                                // Scheme: reverse
        return reverseRec(NULL_STRINGLIST );
      }
  
    private StringSList reverseRec( StringSList re ) {
      
        if ( isNull() ) {                      // metodo di supporto: private!
          return re;
        } else {
          // return cdr().reverseRec( new IntSList(car(),re) );
          return cdr().reverseRec( re.cons(car()) );
        }
      }
  
  
    // ----- Rappresentazione testuale (String) di una lista
  
    public String toString() {                 // ridefinizione del metodo generale
                                               // per la visualizzazione testuale
        if ( isNull() ) {
          return "()";
        } else {
          String rep = "(" + car();
          StringSList r = cdr();
          while ( !r.isNull() ) {
            rep = rep + ", " + r.car();
            r = r.cdr();
          }
          return ( rep + ")" );
        }
      }
}
