/*
 * Problema 12
 * Il protocollo pubblico della classe Board, che modella la scacchiera per affrontare il rompicapo delle N regine, è
 * definito dal costruttore e dai metodi introdotti a lezione, dove i, j rappresentano indici interi, rispettivamente di riga e
 * colonna, compresi fra 1 e la dimensione N della scacchiera:
    Board b = new Board(n) creazione di una scacchiera nxn vuota
    b.size() : int dimensione della scacchiera
    b.queensOn () : int numero di regine collocate sulla scacchiera
    b.underAattack(i,j) : boolean la posizione di coordinate <i, j> è minacciata?
    b.addQueen(i,j) : Board nuova scacchiera con una regina in posizione <i, j> che si aggiunge alla configurazione di b
    b.arrangement() : String codifica testuale della configurazione
 * Il file Queens.java associato a questo problema realizza la strategia già discussa per contare il numero di soluzioni.
 * Una rappresentazione interna alternativa delle istanze della classe Board si compone di 7 elementi (variabili di istanza):
    • la dimensione della scacchiera (int);
    • il numero di regine collocate nella scacchiera (int);
    • 4 liste di indici (IntSList oppure SList<Integer>), per rappresentare rispettivamente le codifiche numeriche delle righe, delle colonne, 
      delle diagonali ascendenti verso destra e delle diagonali discendenti verso destra che sono minacciate da una regina collocata sulla scacchiera;
    • la codifica testuale della configurazione secondo le convenzioni in uso da parte degli scacchisti (String).
 * In particolare, righe e colonne possono essere codificate dalle corrispondenti coordinate; le
 * diagonali ascendenti verso destra dalla differenza delle coordinate delle caselle che ne
 * fanno parte, che è invariante; quelle discendenti verso destra dalla somma invariante delle
 * coordinate. In base ai criteri delineati, una possibile rappresentazione della configurazione
 * della scacchiera 5 x 5 illustrata qui a fianco è la seguente, dove le righe sono numerate dal
 * basso verso l’alto a partire da 1, come è consueto nella formulazione schematica dei
 * problemi del gioco degli scacchi:
 * < 5 , 2 , (1, 3) , (4, 3) , (-3, 0) , (5, 6) , " d1 c3 " >
 * In altri termini, dei 7 elementi che caratterizzano la nuova rappresentazione degli oggetti di tipo Board, i primi due e
 * l’ultimo sono gli stessi utilizzati nella versione discussa a lezione, mentre le quattro liste di indici sostituiscono il
 * predicato. Questa nuova impostazione consente di controllare se la riga, la colonna, l’una o l’altra diagonale che si
 * incrociano in corrispondenza a una casella della scacchiera di coordinate (x,y) sono minacciate da qualche regina
 * verificando se le rispettive codifiche (indici x, y, x–y e x+y) appartengono o meno alle liste appropriate.
 * Definisci le variabili di istanza della classe Board e realizza il costruttore e i metodi del protocollo in base alle
 * indicazioni fornite sopra. Sperimenta quindi il programma per determinare il numero di soluzioni del rompicapo delle n
 * regine e verifica che i risultati siano in accordo con la seguente tabella:
 */
public class Board {
  //Una regina attacca in orizzontale,verticale o diagonale
  //Le scacchiere si numerano dal basso verso l'alto

  private int size;
  private int numberOfQueen;
  private IntSList righeMinacciate;
  private IntSList colonneMinacciate;
  private IntSList diagonaliMinacciate;
  private IntSList diagonaliInverseMinacciate;
  private String positionsOfQueens;
  
  public Board (int n) {
    //Una diagonale è somma, una sottrazione (righe operatore colonna)
    size = n;
    numberOfQueen=0;
    righeMinacciate=IntSList.NULL_INTLIST;
    colonneMinacciate=IntSList.NULL_INTLIST;
    diagonaliMinacciate=IntSList.NULL_INTLIST;
    diagonaliInverseMinacciate=IntSList.NULL_INTLIST;
    positionsOfQueens="";
  }
  
  private Board (Board b,int i,int j){
    size=b.size();
    numberOfQueen=b.queensOn()+1;
    righeMinacciate=b.righeMinacciate.cons(i);
    colonneMinacciate=b.colonneMinacciate.cons(j);
    diagonaliMinacciate=b.diagonaliMinacciate.cons(i+j);
    diagonaliInverseMinacciate=b.diagonaliInverseMinacciate.cons(i-j);
    positionsOfQueens=b.positionsOfQueens + " " + toLetter(i) + j;
  }
  
  private static char toLetter(int i) {
    String a="abcdefghilmnopqrtuvz";
    return (a.charAt(i-1));
  }
  
  public int size (){
    return size;
  }
  
  public int queensOn(){
    return numberOfQueen;
  }
  
  public Boolean underAttack (int i, int j) {
    if (isThere(i,righeMinacciate) || 
        isThere(j,colonneMinacciate) ||
        isThere(i+j,diagonaliMinacciate) ||
        isThere(i-j,diagonaliInverseMinacciate)) {
      return true;
    } else {
      return false;
      }
  }
  private static Boolean isThere (int n, IntSList l) {
    Boolean b=false; 
    for (int i=0;(i<l.length() && !(b));i++){
      if (l.listRef(i)==n)
        return true;
    }
    return b; //false
  }
  public Board addQueen (int i, int j) {
    return new Board(this,i,j);
  }
  
  public String arrangement (){
    return positionsOfQueens;
  }
  
  public static int numberOfSolutions (int i) {
    return numberOfComplitions ( new Board(i));
  }
  
  private static int numberOfComplitions (Board b) {  //era Complitions
    int sol=0;
    if (b.numberOfQueen == b.size()){
      return 1;
    } else {
      int n=b.size();
      int i=b.queensOn()+1; //prima riga disponibile
      for (int j=1;j<=n;j++){
        if (!(b.underAttack(i,j))) {
          sol=sol + numberOfComplitions (b.addQueen(i,j));
        }
      } //for
      return sol;
    } //else
  } //numberOfComplitions
   
}  //class 