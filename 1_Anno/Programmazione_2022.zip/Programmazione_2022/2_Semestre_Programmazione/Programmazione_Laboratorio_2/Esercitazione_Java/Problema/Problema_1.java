/*
 * Esercitazione sulla codifica in Java
 * Dato un intero non negativo in notazione ternaria bilanciata (stringa di cifre –/./+), 
 * la seguente procedura in Scheme restituisce la rappresentazione dell’intero successivo,
 * calcolata operando direttamente sulle cifre a livello testuale:
    (define btr-succ                        ; val: stringa di -/./+
    (lambda (btr)                           ; btr: stringa di -/./+
        (let ((n (string-length btr)))      ; (brt = "." oppure inizia con "+")
            (let ((lsb (string-ref btr (- n 1))))
                (if (= n 1)
                    (if (char=? lsb #\+)
                        "+-"
                        "+")
                    (let ((pre (substring btr 0 (- n 1))))
                        (if (char=? lsb #\+)
                            (string-append (btr-succ pre) "-")
                            (string-append pre (if (char=? lsb #\-) "." "+"))
                            ))
                        )))
                    ))
* Traduci in Java la procedura btr-succ e verifica sperimentalmente che i risultati siano consistenti con quelli ottenuti
* applicando la procedura riportata sopra nell’ambiente DrRacket.
* Considera il programma in Scheme per realizzare la procedura ones-complement che, data una stringa 
* di bit,restituisce la rappresentazione del corrispondente complemento a uno, in cui le cifre 0 e 1 
* sono “scambiate” fra loro (sorgenti Scheme: recursion_strings.scm di cui è riportato il link anche a 
* fianco di questo testo). Prova a trasformare il programma per realizzarne una versione imperativa in 
* Java, che non si avvalga della ricorsione ma applichi il costrutto for per l’iterazione. Sperimenta 
* infine il programma nell’ambiente BlueJ oppure DrJava e verificane i risultati.
*/

public class Problema_1
{
   public static String BtrSucc (String btr) { 
       int n = btr.length();
       char lsb = btr.charAt(n-1);
           if(n ==1){
                if(lsb == '+'){
                    return "+-" ;
                }
                else{
                    return "+";
                }
            }
            else{
                String pre = btr.substring(0, n-1);
                if(lsb == '+'){
                    return BtrSucc(pre) + "-";
                }
                else{
                    if(lsb == '-') {
                        return pre + ".";
                    }
                    else
                        return pre + "+";
                }
            }
   }
   
   public static String BitComplement(String bit){
       if(bit.equals("0")){
           return "1";
       }
       else{
           return "0";
       }
   }
   
   public static String OnesComplement(String bin){
      int n = bin.length();
      String conv1="";
       if(bin.equals("")){
          return "";
      }
      else{
          for(int i=0 ; i<n; i=i+1){
            conv1= conv1 + BitComplement(Character.toString(bin.charAt(i)));
          }
        return conv1;
      }
   }
}
