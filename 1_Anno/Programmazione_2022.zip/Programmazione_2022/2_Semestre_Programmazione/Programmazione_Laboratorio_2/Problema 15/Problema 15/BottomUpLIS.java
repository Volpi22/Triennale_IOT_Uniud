/*
 * Problema 15
 * Data una sequenza s di n interi positivi, rappresentata da un array, il seguente programma in Java calcola la lunghezza
 * della più lunga sottosequenza di s strettamente crescente (llis: length of the longest increasing subsequence).
 * Per una descrizione del problema e dell’algoritmo ricorsivo, accompagnata da alcuni esempi, fai riferimento
 * all’esercitazione precedente, relativa al progetto “Longest Increasing Subsequence” – parte I (12/05/2022).
     public static int llis( int[] s ) { // s[i] > 0 per i in [0,n-1], dove n = s.length
         return llisRec( s, 0, 0 );
     }
    
     private static int llisRec( int[] s, int i, int t ) {
         if ( i == s.length ) { // i = n : coda di s vuota
             return 0;
     } else if ( s[i] <= t ) { // x = s[i] ≤ t : x non può essere scelto
         return llisRec( s, i+1, t );
     } else { // x > t : x può essere scelto o meno
         return Math.max( 1+llisRec(s,i+1,s[i]), llisRec(s,i+1,t) );
     }
     }
 * La struttura di supporto appropriata per applicare la tecnica di memoization seguendo l’impostazione proposta al punto
 * 2 dell’esercitazione precedente è una matrice quadrata (n+1) x (n+1).
 * Una matrice di questo tipo per la sequenza s = < 2, 7, 5, 7, 4 > è illustrata nella figura della pagina seguente (n=5)
 * attraverso una griglia (tratti orizzontali e verticali blu) i cui nodi corrispondono agli elementi della matrice.
 * Ciascuna colonna è associata a una “coda” della sequenza s a partire dall’indice i, e tale porzione della sequenza si
 * legge in alto, guardando gli elementi in neretto a destra della colonna di indice i. In particolare, l’indice 0 corrisponde
 * all’intera sequenza s (tutti gli elementi sono a destra), mentre n corrisponde a una coda di s vuota (non ci sono elementi
 * a destra della colonna n).
 * Ciascuna riga è invece associata a un valore del parametro t, in accordo con l’interpretazione t = s[j] se 0 ≤ j < n
 * oppure t = 0 se j = n, dove j è l’indice di riga della matrice. Il valore di t, in verde nella figura, si legge a sinistra in
 * corrispondenza alla riga j.
 * Gli indici di colonna (i) e di riga (j) sono riportati in grigio, rispettivamente sotto la griglia e a destra della griglia.
 * Questa stessa struttura può essere utilizzata per applicare una tecnica di programmazione dinamica bottom-up, basata su
 * costrutti iterativi anziché sulla ricorsione, in cui il programmatore controlla esplicitamente ogni passo del processo di
 * calcolo, in particolare l’ordine delle operazioni da effettuare per determinare i valori da assegnare ai nodi della griglia,
 * cioè agli elementi della matrice. Si può anche osservare che i valori dei nodi compresi nell’area a fondo grigio non sono
 * rilevanti al fine di calcolare la lunghezza della sottosequenza crescente più lunga di s in quanto, considerando i possibili
 * argomenti delle invocazioni di llisRec, t è sempre il valore di un elemento di s la cui posizione precede strettamente i
 * e pertanto non può mai essere determinato da un elemento di indice j ≥ i. (Ciò significa che ci si può occupare o meno
 * di quei nodi, a seconda di cosa sembra più semplice; presta però attenzione al fatto che, pur essendo n ≥ i, n non è
 * indice di un elemento della sequenza e quindi i nodi della riga più in basso sono tutti significativi.)
 * Le schede llis_bottom_up.pdf, consultabili in forma di presentazione, illustrano il processo di elaborazione per
 * assegnare valori agli elementi della matrice nell’esempio considerato. Gli archi rossi orientati che hanno origine in un
 * nodo riflettono le ricorsioni di llisRec (una o due) per i valori dei parametri corrispondenti ai nodi coinvolti.
 * Completa il programma preimpostato nel file BottomUpLIS.java, senza modificare le parti già codificate, per
 * realizzare la procedura llisDP (metodo statico) applicando una tecnica di programmazione dinamica bottom-up in
 * accordo con le indicazioni fornite sopra. Verifica quindi che i risultati ottenuti siano coerenti con i valori calcolati dal
 * programma ricorsivo originale.
 * Analogamente a quanto visto a lezione per il problema della sottosequenza comune più lunga (LCS), a partire dalla
 * matrice risultante alla fine dall’elaborazione oggetto del punto precedente è possibile ricostruire una sottosequenza
 * crescente più lunga (LIS). A tale proposito è sufficiente identificare un opportuno cammino attraverso la matrice che
 * percorre i nodi corrispondenti alle ricorsioni di llisRec che hanno contribuito al risultato finale.
 * Le schede lis_percorso.pdf, consultabili in forma di presentazione, illustrano il processo di elaborazione per
 * identificare un percorso utile nell’esempio considerato. Gli archi verdi riflettono le ricorsioni di llisRec che hanno
 * fornito i valori utilizzati per calcolare il risultato: in base alla codifica degli argomenti di llisRec adottata, archi
 * orizzontali corrispondono a elementi di s non selezionati; archi inclinati corrispondono a elementi presi a far parte della
 * sottosequenza (evidenziati in questo caso dal fondo verde chiaro).
 * Completa il programma preimpostato nel file BottomUpLIS.java, senza modificare le parti già codificate, per
 * realizzare la procedura lisDP (metodo statico) applicando una tecnica di programmazione dinamica bottom-up
 * completata da un cammino attraverso la matrice in accordo con le indicazioni fornite. Verifica quindi che i risultati
 * ottenuti siano coerenti con quanto ci si dovrebbe attendere.
 */
public class BottomUpLIS {


  // Length of Longest Increasing Subsequence (LLIS):
  // Programmazione dinamica bottom-up
  
  public static int llisDP( int[] s ) {
  
    int n = s.length;
    
    int[][] mem = new int[ n+1 ][ n+1 ];
    
    // Matrice: valori delle ricorsioni di llisRec
    // relativi a diversi valori degli argomenti
    
    for ( int j=0; j<=n; j=j+1 ) {
    
      // --------------------------------------------------
      //  Inserisci qui i comandi per registrare i valori
      //  corrispondenti ai casi base della ricorsione
      // --------------------------------------------------
      
      mem[j][n] = 0;
    }
    
    int[] t = new int[n+1];
    for(int i = 0; i < n; i++){
        t[i] = s[i];
    }
    t[n] = 0;
    
    for ( int i=n-1; i>=0; i=i-1 ) {
      for ( int j=0; j<=n; j=j+1 ) {
      
        // ------------------------------------------------
        //  Inserisci qui le strutture di controllo
        //  appropriate e i comandi per registrare
        //  i valori corrispondenti ai casi ricorsivi
        // ------------------------------------------------
        
        if(s[i] > t[j]){    //Se s[i] > t
            mem[j][i] = Math.max(mem[i][i+1] + 1, mem[j][i+1]);
        }else{
            mem[j][i] = mem[j][i+1];
        }
    }}
    
    // ----------------------------------------------------
    //  Inserisci di seguito l'elemento della matrice
    //  il cui valore corrisponde a llis(s) :
    
    return  mem[n][0]/* elemento appropriato della matrice */;
    
    // ----------------------------------------------------
  }
  
}  // class BottomUpLIS

