
/**
 * null
 * 
 * null?
 * 
 * car
 * 
 * cdr
 * 
 * cons
 */

public class IntSList
{
    public static final IntSList NULL_INTLIST = new IntSList();
    
    private final boolean empty;
    private final int first;
    private final IntSList rest;
    
    public IntSList()
    {
        empty = true;
        first = 0;
        rest = null;
    }
    
    public IntSList(int n, IntSList s)
    {
        empty = false;
        first = n;
        rest = s;
    }
    
    public boolean isNull()
    {
        return empty;        
    }
    
    public int car()
    {
        return first;
    }
    
    public IntSList cdr()
    {
        return rest;
    }
    
    public IntSList cons(int n)
    {
        return new IntSList(n, this);
    }
    
    public int length()
    {
        if(this.empty == true)
        {
            return 0;
        } else
        {
            return 1 + cdr().length();
        }
    }
    
    public int listRef (int i)
    {
        if(i == 0)
        {
            return car();
        } else
        {
            return cdr().listRef(i - 1);
        }
    }  
    
    public boolean equals(IntSList s)
    {
        if(this.isNull() || s.isNull())
        {
            return (this.isNull() && s.isNull());
        } else if(this.car() == s.car())
        {
            return this.cdr().equals(s.cdr());
        } else
        {
            return false;
        }
    }
    
    public IntSList append(IntSList s)
    {
        if(this.isNull())
        {
            return s;
        } else
        {
            return (cdr().append(s)).cons(car());
        }
    }
    
    public IntSList reverse()
    {
        return reverseRec(NULL_INTLIST);
    }
    
    private IntSList reverseRec(IntSList s)
    {
        if(isNull())
        {
            return s;
        } else
        {
            return cdr().reverseRec(s.cons(car()));
        }
    }
}
