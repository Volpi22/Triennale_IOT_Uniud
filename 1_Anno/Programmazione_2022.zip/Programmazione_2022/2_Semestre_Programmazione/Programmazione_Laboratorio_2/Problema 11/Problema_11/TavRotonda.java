public class TavRotonda
{
    private final IntSList cavalieri;
    
    private TavRotonda(IntSList lista) // new RoundTable(n)
    {
        cavalieri = lista;
    }
    
    public TavRotonda(int n)
    {
        cavalieri = range(1, n);
    }
    
    public int quantiCavalieri() // numberOfKnights() 
    {
        return cavalieri.length();
    }
    
    public IntSList chiHaLaBrocca() // servingKnights() 
    {
        IntSList list1 = IntSList.NULL_INTLIST.cons(cavalieri.car());
        IntSList list2 = list1.cons(cavalieri.cdr().car());
        return list2;
    }
    
    public TavRotonda serviSidro() // serveNeighbour()
    {
        IntSList TavRoto = (cavalieri.cdr().cdr().cdr()).cons(cavalieri.car()).cons(cavalieri.cdr().car());
        return new TavRotonda(TavRoto); // D E F ... A B
    }
    
    public TavRotonda passaBrocca() // passJug() 
    {
        IntSList primo = IntSList.NULL_INTLIST.cons(cavalieri.car()); // ""+ D
        IntSList secondo = IntSList.NULL_INTLIST.cons(cavalieri.cdr().car()); // ""+E
        IntSList nuovaLista = (cavalieri.cdr().cdr()).append(secondo).append(primo); // F ... A B D E
        
        return new TavRotonda(nuovaLista);
    }
    
    public static IntSList range(int inf, int sup)
    {
        if(inf > sup)
        {
            return new IntSList();
        } else
        {
            return range(inf + 1, sup).cons(inf);
        }
    }
}
