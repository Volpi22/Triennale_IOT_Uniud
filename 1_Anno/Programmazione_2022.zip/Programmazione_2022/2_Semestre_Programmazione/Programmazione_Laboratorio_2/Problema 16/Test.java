/*
 * Problema 16: esercitazione moodle
 */
public class Test
{
    public static int middleOfTree(int x, int y, int z){
    int k=0;
    if(x>=y){
        if(y>=z){
            k=y;
        }
        else if ((y<z)&&(z>x)){
            k=x;
        }
        else{
            k=z;
        }
    }
    else if(x<y){
        if(x>z){
            k=x;
        }
        else if((x<y)&&(z<y)){
            k=z;
        }
        else{
            k=y;
        }
    }
    return k;
}
public static int lunchTime(int branch, int leaf, int rest){
    int cibo=0;
    int posizione=0;
    while(posizione<=branch)
    {
        if (posizione%leaf == 0){
            cibo=cibo+1;
        }
        else{
            cibo=cibo;
        }
        posizione=posizione+rest;
    }
    return cibo;
}
public static double[] closestPair(double []l){
    int n=l.length;
    int a=0;
    int b=1;
    double start = Math.abs(l[1]-l[0]);
        for(int i=0; i<n; i=i+1){
            for(int j=i+1; j<n; j=j+1){
                if(Math.abs(l[j]-l[i])<start){
                    start=Math.abs(l[j]-l[i]);
                    a=i;
                    b=j;
                }
            }
        }
        if(l[a]<l[b]){
            return new double[]{l[a],l[b]};
                }
        else{
            return new double[]{l[b],l[a]};
                }
    }
public static boolean symmetricalMatrix(double[][]matrix){
    int n=matrix.length;
    boolean control=true;
    for(int i=0; (control=true && i<n); i=i+1){
        for(int j=i+1; (control=true && j<n); j=j+1){
           if(matrix[i][j]!=matrix[j][i]){
               control=false;
           }
          }}
    return control;
        }
}
