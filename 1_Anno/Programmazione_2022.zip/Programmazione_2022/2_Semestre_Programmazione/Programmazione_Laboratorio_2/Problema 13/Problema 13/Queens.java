import queens.*;
/*
 * Problema 13
 * In relazione al rompicapo delle N regine, modifica la realizzazione della classe Board sviluppata nella precedente
 * esercitazione in laboratorio (problema 12) utilizzando un’istanza di SList<SList<Integer>> per rappresentare le
 * coppie di coordinate in cui sono collocate le regine disposte sulla scacchiera (in sostituzione delle quattro liste di interi).
 * Il tipo degli elementi di una lista può essere infatti a sua volta una lista — nel caso specifico la lista di due interi che
 * denota una coppia di coordinate. Intendendo come di consueto le liste in stile Scheme, l’interpretazione del costrutto
 * composto SList<SList<Integer>> è dunque “liste di (liste di interi)” e risulta perfettamente definita in Java.
 * Sulla base di questa impostazione, una possibile rappresentazione della configurazione
 * della scacchiera 5 x 5 illustrata qui a fianco è la seguente, dove le righe sono numerate dal
 * basso verso l’alto e le colonne da sinistra a destra, in entrambi i casi a partire dall’indice 1:
 * < 5 , 3 , ((1, 4) , (3, 3) , (4, 5) ) , " d1 c3 e4 " >
 * Dei 4 elementi che caratterizzano la nuova realizzazione, i primi due e l’ultimo sono gli
 * stessi utilizzati in precedenza. Per verificare se una casella di coordinate (i, j) è minacciata
 * da una delle regine regine disposte sulla scacchiera sarà poi sufficiente controllare se per
 * una delle coppie (u, v) contenute nella lista di tipo SList<SList<Integer>> si abbia
 * i = u oppure j = v oppure i–j = u–v o infine i+j = u+v.
 * Sperimenta questa versione della classe Board attraverso il programma Queens.java, discusso a lezione, che
 * codifica gli algoritmi per determinare il numero di soluzioni e la lista delle soluzioni — di tipo SList<Board>.
 * Verifica, in particolare, il numero delle soluzioni che si ottengono al variare della dimensione della scacchiera.
 * 
 * Rompicapo delle "n regine"
 *
 * Dato astratto "configurazione della scacchiera":  Board
 *
 * Operazioni:
 *
 *   new Board( int n )           :  costruttore (scacchiera vuota)
 *
 *   size()                       :  int
 *
 *   queensOn()                   :  int
 *
 *   underAttack( int i, int j )  :  boolean
 *
 *   addQueen( int i, int j )     :  Board
 *
 *   arrangement()                :  String
 *
 *
 * Board b;
 *
 *   new Board(n)           costruttore della scacchiera n x n vuota;
 *   b.size()               dimensione n della scacchiera b;
 *   b.queensOn()           numero di regine collocate nella scacchiera b;
 *   b.underAttack(i,j)     la posizione <i,j> e' minacciata?
 *   b.addQueen(i,j)        scacchiera che si ottiene dalla configurazione b
 *                          aggiungendo una nuova regina in posizione <i,j>
 *                          (si assume che la posizione non sia minacciata);
 *   b.arrangement() :      descrizione "esterna" della configurazione
 *                          (convenzioni scacchistiche).
 */


public class Queens {
  
  public static final SList<Board> NULL_BOARDLIST = new SList<Board>();
  
  
  /*
   * I. Numero di soluzioni:
   *
   *
   * Il numero di modi diversi in cui si possono disporre n regine
   *
   *   numberOfSolutions( n )
   *
   * in una scacchiera n x n e' dato dal numero di modi diversi in
   * cui si puo' completare la disposizione delle regine a partire
   * da una scacchiera n x n inizialmente vuota
   *
   *   numberOfCompletions( new Board(n) )
   */
  
  public static int numberOfSolutions( int n ) {
    
    return numberOfCompletions( new Board(n) );
  }
  
  
  /*
   * Il numero di modi in cui si puo' completare la disposizione
   * a partire da una scacchiera b parzialmente configurata
   *
   *   numberOfCompletions( b )   : int
   *
   * dove k regine (0 <= k < n) sono collocate nelle prime k righe
   * di b, si puo' determinare a partire dalle configurazioni
   * che si ottengono aggiungendo una regina nella riga k+1 in tutti
   * i modi possibili (nelle posizioni che non sono gia' minacciate)
   *
   *   for ( int j=1; j<=n; j=j+1 ) {
   *     if ( !b.underAttack(i,j) ) { ... b.addQueen(i,j) ... }
   *   }
   *
   * calcolando ricorsivamente per ciascuna di queste il numero
   * di modi in cui si puo' completare la disposizione
   *
   *   numberOfCompletions( b.addQueen(i,j) )
   *
   * e sommando i valori che ne risultano
   *
   *   count = count + numberOfCompletions( ... )
   *
   * Se invece la scacchiera rappresenta una soluzione (q == n)
   * c'e' un solo modo (banale) di completare la disposizione:
   * lasciare le cose come stanno!
   */
  
  private static int numberOfCompletions( Board b ) {
  
    int n = b.size();
    int q = b.queensOn();
    
    if ( q == n ) {
    
      return 1;
    
    } else {
    
      int i = q + 1;
      int count = 0;
      
      for ( int j=1; j<=n; j=j+1 ) {
        if ( !b.underAttack(i,j) ) {
        
          count = count + numberOfCompletions( b.addQueen(i,j) );
      }}
      return count;
    }
  }
  
  
  /*
   * II. Lista delle soluzioni:
   *
   * Confronta il programma precedente!
   */
  
  public static SList<Board> listOfAllSolutions( int n ) {
  
    return listOfAllCompletions( new Board(n) );
  }
  
  
  private static SList<Board> listOfAllCompletions( Board b ) {
  
    int n = b.size();
    int q = b.queensOn();
    
    if ( q == n ) {
    
      return ( NULL_BOARDLIST.cons(b) );
    
    } else {
    
      int i = q + 1;
      SList<Board> solutions = NULL_BOARDLIST;
      
      for ( int j=1; j<=n; j=j+1 ) {
        if ( !b.underAttack(i,j) ) {
        
          solutions = solutions.append( listOfAllCompletions(b.addQueen(i,j)) );
      }}
      return solutions;
    }
  }
  
  
  // Eventuale programma principale
  
  public static void main( String args[] ) {
  
    int n = Integer.parseInt( args[0] );
    
    ChessboardView gui = new ChessboardView( n ); 
    int s=numberOfSolutions(n);
    SList<Board> k= listOfAllSolutions(n);
    Board t;
    for (int i=0;i<s;i++)
    {
      t=k.car();
      k=k.cdr();
      gui.setQueens( t.arrangement() );
    }
    
  }

}  // class Queens

