public class Board {
  //Una regina attacca in orizzontale,verticale o diagonale
  //Le scacchiere si numerano dal basso verso l'alto

  private int size;
  private int numberOfQueen;
  private SList<Integer> righeMinacciate;
  private SList<Integer> colonneMinacciate;
  private SList<Integer> diagonaliMinacciate;
  private SList<Integer> diagonaliInverseMinacciate;
  private String positionsOfQueens;
  
  private SList<Integer> NULL_INTLIST = new SList<Integer>();
  
  public Board (int n) {
    size = n;
    numberOfQueen=0;
    righeMinacciate=NULL_INTLIST;
    colonneMinacciate=NULL_INTLIST;
    diagonaliMinacciate=NULL_INTLIST;
    diagonaliInverseMinacciate=NULL_INTLIST;
    positionsOfQueens="";
  }
  
  private Board (Board b,int i,int j){
    size=b.size();
    numberOfQueen=b.queensOn()+1;
    righeMinacciate=b.righeMinacciate.cons(i);
    colonneMinacciate=b.colonneMinacciate.cons(j);
    diagonaliMinacciate=b.diagonaliMinacciate.cons(i+j);
    diagonaliInverseMinacciate=b.diagonaliInverseMinacciate.cons(i-j);
    positionsOfQueens=b.positionsOfQueens + " " + toLetter(i) + toEx(j);
  }
  
  private static char toLetter(int i) {
    String a="abcdefghilmnopqrtuvz"; 
    return (a.charAt(i-1));
  }
  
  private static char toEx(int i) {
    String a="123456789ABCDEF"; 
    return (a.charAt(i-1));
  }
  
  public int size (){
    return size;
  }
  
  public int queensOn(){
    return numberOfQueen;
  }
  
  public Boolean underAttack (int i, int j) {
    if (isThere(i,righeMinacciate) || 
        isThere(j,colonneMinacciate) ||
        isThere(i+j,diagonaliMinacciate) ||
        isThere(i-j,diagonaliInverseMinacciate)) {
      return true;
    } else {
      return false;
      }
  }

  private static Boolean isThere (int n, SList<Integer> l) {
    Boolean b=false;
    for (int i=0;(i<l.length() && !(b));i++){
      if (l.listRef(i)==n)
        return true;
    }
    return b; //false
  }
  
  public Board addQueen (int i, int j) {
    return new Board(this,i,j);
  }
  
  public String arrangement (){
    return positionsOfQueens;
  }

}  //class 